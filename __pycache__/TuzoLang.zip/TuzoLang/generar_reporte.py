"""
Genera el reporte PDF (Reporte_EquipoX.pdf).

1. Edita las constantes EQUIPO e INTEGRANTES.
2. Guarda tus capturas de pantalla en docs/capturas/ con los nombres de CAPTURAS.
3. Ejecuta:  python generar_reporte.py
"""
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

# ============================ EDITA ESTOS DATOS ============================
EQUIPO = "Equipo X"
LENGUAJE = "TuzoLang"
MATERIA = "Lenguajes y Autómatas"
INTEGRANTES = [                        # (nombre, rol)
    ("Nombre Integrante 1", "Diseño del lenguaje y gramática (PLY)"),
    ("Nombre Integrante 2", "Interfaz gráfica (PyQt6)"),
    ("Nombre Integrante 3", "Análisis semántico y pruebas"),
    ("Nombre Integrante 4", "Documentación y reporte"),
]
URL_REPO = "https://github.com/USUARIO/TuzoLang"
# ===========================================================================

RAIZ = Path(__file__).resolve().parent
SALIDA = RAIZ / f"Reporte_{EQUIPO.replace(' ', '')}.pdf"

CAPTURAS = [
    ("01_interfaz.png", "Interfaz principal del editor con un programa cargado."),
    ("02_copiar_pegar.png", "Funciones de edición: cortar, copiar y pegar (menú Editar y barra de herramientas)."),
    ("03_buscar.png", "Barra de búsqueda y reemplazo (Ctrl+F / Ctrl+H) con conteo de coincidencias."),
    ("04_código_valido.png", "Análisis de un programa VÁLIDO: banner verde y sin errores."),
    ("05_error_sintaxis.png", "Análisis de un programa INVÁLIDO: errores léxicos y sintácticos con línea y columna."),
    ("06_error_semantico.png", "Análisis de un programa INVÁLIDO: errores semánticos y advertencias."),
    ("07_tokens.png", "Pestaña de tokens reconocidos por el analizador léxico."),
]

estilos = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=estilos["Heading1"], textColor=colors.HexColor("#0b3d91"), spaceAfter=10)
H2 = ParagraphStyle("H2", parent=estilos["Heading2"], textColor=colors.HexColor("#0b3d91"))
CUERPO = ParagraphStyle("Cuerpo", parent=estilos["BodyText"], fontSize=10.5, leading=15)
CODIGO = ParagraphStyle("Codigo", fontName="Courier", fontSize=7.2, leading=8.6)
CENTRO = ParagraphStyle("Centro", parent=CUERPO, alignment=TA_CENTER)
CELDA = ParagraphStyle("Celda", parent=CUERPO, fontSize=9, leading=11)


def latin1(texto: str) -> str:
    """Las fuentes estándar de PDF no tienen todos los símbolos Unicode."""
    return texto.encode("latin-1", "replace").decode("latin-1")


def código(ruta, inicio=None, fin=None):
    líneas = (RAIZ / ruta).read_text(encoding="utf-8").splitlines()
    if inicio:
        i = next(n for n, l in enumerate(líneas) if inicio in l)
        j = next((n for n, l in enumerate(líneas) if fin and fin in l and n > i), len(líneas))
        líneas = líneas[i:j]
    return Preformatted(latin1("\n".join(líneas)), CODIGO)


def tabla(filas, anchos, encabezado=True):
    t = Table([[Paragraph(latin1(str(c)), CELDA) for c in f] for f in filas], colWidths=anchos, repeatRows=1)
    estilo = [("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if encabezado:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbe6fb"))]
    t.setStyle(TableStyle(estilo))
    return t


def p(texto, estilo=CUERPO):
    return Paragraph(latin1(texto), estilo)


def portada():
    s = [Spacer(1, 3.5 * cm), p(f"<b>{LENGUAJE}</b>", ParagraphStyle("T", parent=H1, fontSize=40, leading=48, alignment=TA_CENTER)),
         Spacer(1, 0.4 * cm), p("Lenguaje de programación con editor en PyQt6 y analizador en PLY", CENTRO), Spacer(1, 1.5 * cm),
         p(f"<b>{EQUIPO}</b>", ParagraphStyle("E", parent=CENTRO, fontSize=22, leading=28)),
         Spacer(1, 0.6 * cm), p(MATERIA, CENTRO), Spacer(1, 1.5 * cm), p("<b>Integrantes</b>", CENTRO)]
    s += [p(nombre, CENTRO) for nombre, _ in INTEGRANTES]
    s += [Spacer(1, 1.5 * cm), p(f"Repositorio: {URL_REPO}", CENTRO), PageBreak()]
    return s


def descripcion():
    s = [p("1. Descripción del lenguaje", H1),
         p(f"<b>{LENGUAJE}</b> es un lenguaje de programación con palabras clave en español pensado para "
           "enseñar los fundamentos de la programación estructurada: variables, expresiones, condicionales y ciclos. "
           "Cada programa se escribe dentro de un bloque <b>programa Nombre { ... }</b> y los archivos usan la "
           "extensión <b>.tuzo</b>. El sistema analiza el código en tres fases (léxica, sintáctica y semántica) "
           "e indica si es valido o muestra cada error con su línea y columna."),
         p("Reglas principales", H2),
         tabla([["Elemento", "Regla"],
                ["Estructura", "programa Nombre { sentencias }"],
                ["Variables", "guardar x = valor;  o  guardar x;  (el tipo se infiere del valor)"],
                ["Tipos", "entero, decimal, texto (\"...\"), logico (verdadero / falso)"],
                ["Aritméticos", "+  -  *  /  %  (el + también concatena texto)"],
                ["Comparación", "==  !=  <  >  <=  >="],
                ["Lógicos", "y, o, no"],
                ["Condicional", "si (cond) { } sino si (cond) { } sino { }"],
                ["Ciclos", "mientras (cond) { }    repetir i desde 1 hasta 10 { }"],
                ["Salida", "mostrar(expr, expr, ...);"],
                ["Comentarios", "// de línea   y   /* de bloque */"]],
               [3.5 * cm, 13.5 * cm]),
         Spacer(1, 0.4 * cm), p("Ejemplo", H2),
         código("ejemplos/valido.tuzo"), Spacer(1, 0.3 * cm), KeepTogether([p("Verificaciones del análisis", H2),
         tabla([["Fase", "Qué detecta"],
                ["Léxica", "Caracteres no reconocidos, cadenas sin cerrar, comentarios de bloque sin cerrar"],
                ["Sintáctica", "Sentencias mal formadas, falta de ; ) } y otros tokens inesperados "
                               "(reporta varios errores gracias a la recuperación en modo pánico)"],
                ["Semántica", "Variables no declaradas o redeclaradas, tipos incompatibles, condiciones no lógicas, "
                              "división entre cero"],
                ["Advertencia", "Variables declaradas que nunca se usan (no invalidan el programa)"]],
               [3.5 * cm, 13.5 * cm])]),
         Spacer(1, 0.4 * cm), p("Roles del equipo", H2),
         tabla([["Integrante", "Rol"]] + [list(f) for f in INTEGRANTES], [6 * cm, 11 * cm]), PageBreak()]
    return s


def gramatica():
    s = [p("2. Explicación de la gramática", H1),
         p("La definición vive en <b>lenguaje/lexico.py</b> (tokens y expresiones regulares) y en "
           "<b>lenguaje/sintactico.py</b> (producciones). A continuación se resume y después se incluye el código real."),
         p("2.1 Tokens y expresiones regulares", H2),
         tabla([["Token", "Expresión regular", "Ejemplo"],
                ["ID", r"[^\W\d]\w*", "total, edad2"],
                ["ENTERO", r"\d+", "42"],
                ["DECIMAL", r"\d+\.\d+", "3.14"],
                ["CADENA", r'"([^"\\\n]|\\.)*"', '"Hola"'],
                ["Palabras reservadas", "programa guardar mostrar si sino mientras repetir desde hasta verdadero falso y o no",
                 "(se reconocen dentro de ID)"],
                ["Operadores", r"+  -  *  /  %  ==  !=  <=  >=  <  >  =", ""],
                ["Signos", r"; , ( ) { }", ""],
                ["Comentarios", r"//[^\n]*     /\*[\s\S]*?\*/", "se descartan"]],
               [3.6 * cm, 8.4 * cm, 5 * cm]),
         Spacer(1, 0.3 * cm), p("2.2 Producciones (resumen BNF)", H2),
         Preformatted(
             "programa        : PROGRAMA ID '{' sentencias '}'\n"
             "sentencias      : sentencias sentencia | (vacío)\n"
             "sentencia       : declaracion | asignacion | impresion | condicional\n"
             "                | ciclo_mientras | ciclo_repetir | error ';'\n"
             "declaracion     : GUARDAR ID '=' expresion ';' | GUARDAR ID ';'\n"
             "asignacion      : ID '=' expresion ';'\n"
             "impresion       : MOSTRAR '(' lista_expresiones ')' ';'\n"
             "condicional     : SI '(' expresion ')' bloque\n"
             "                | SI '(' expresion ')' bloque SINO bloque\n"
             "                | SI '(' expresion ')' bloque SINO condicional\n"
             "ciclo_mientras  : MIENTRAS '(' expresion ')' bloque\n"
             "ciclo_repetir   : REPETIR ID DESDE expresion HASTA expresion bloque\n"
             "bloque          : '{' sentencias '}'\n"
             "expresion       : expresion OP expresion | NO expresion | '-' expresion\n"
             "                | '(' expresion ')' | ENTERO | DECIMAL | CADENA\n"
             "                | VERDADERO | FALSO | ID\n\n"
             "Precedencia (menor a mayor): o < y < no < == != < < > <= >= < + - < * / % < menos unario",
             CODIGO),
         PageBreak(), p("2.3 Código: lenguaje/lexico.py", H2), código("lenguaje/lexico.py"), PageBreak(),
         p("2.4 Código: lenguaje/sintactico.py (gramática y manejo de errores)", H2),
         código("lenguaje/sintactico.py", "class TuzoParser:"), PageBreak()]
    return s


def capturas():
    s = [p("3. Capturas de pantalla", H1)]
    for archivo, descripcion_ in CAPTURAS:
        ruta = RAIZ / "docs" / "capturas" / archivo
        if ruta.exists():
            ancho, alto = ImageReader(str(ruta)).getSize()
            w = min(16.5 * cm, ancho)
            h = w * alto / ancho
            if h > 10.5 * cm:
                h, w = 10.5 * cm, 10.5 * cm * ancho / alto
            figura = Image(str(ruta), width=w, height=h)
        else:
            figura = Table([[p(f"[ Inserta aquí la captura: docs/capturas/{archivo} ]", CENTRO)]],
                           colWidths=[16.5 * cm], rowHeights=[6 * cm])
            figura.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1, colors.grey),
                                        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f2f2f2")),
                                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        s.append(KeepTogether([figura, Spacer(1, 0.15 * cm), p(f"<i>Figura: {descripcion_}</i>", CENTRO),
                               Spacer(1, 0.5 * cm)]))
    s.append(PageBreak())
    return s


def manual():
    pasos = [
        ("Requisitos", "Python 3.9 o superior, Git y (opcional) PyCharm."),
        ("Clonar el repositorio", f"git clone {URL_REPO}\ncd TuzoLang"),
        ("Crear el entorno virtual", "python -m venv .venv\n"
                                      "Windows:      .venv\\Scripts\\activate\n"
                                      "Linux/macOS:  source .venv/bin/activate"),
        ("Instalar dependencias", "pip install -r requirements.txt"),
        ("Ejecutar la aplicación", "python main.py"),
        ("Analizar un programa", "Escribir código (o cargarlo desde el menú Ejemplos) y presionar F5."),
        ("Ejecutar las pruebas (opcional)", "python -m unittest discover -s tests -v"),
    ]
    s = [p("4. Manual de configuración", H1)]
    for i, (titulo, texto) in enumerate(pasos, 1):
        s.append(p(f"<b>Paso {i}. {titulo}</b>", CUERPO))
        s.append(Preformatted(latin1(texto), ParagraphStyle("c", parent=CODIGO, fontSize=9, leading=11, leftIndent=12)))
        s.append(Spacer(1, 0.25 * cm))
    s.append(p("<b>En PyCharm:</b> File > Open > carpeta del proyecto; configurar el intérprete con el entorno "
               ".venv; abrir main.py y presionar Run."))
    return s


def pie(canvas, doc):
    if doc.page > 1:
        canvas.setFont("Helvetica", 8)
        canvas.drawCentredString(letter[0] / 2, 1.2 * cm, f"{LENGUAJE} - {EQUIPO} - Página {doc.page}")


if __name__ == "__main__":
    doc = SimpleDocTemplate(str(SALIDA), pagesize=letter, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm, title=f"Reporte {EQUIPO} - {LENGUAJE}")
    doc.build(portada() + descripcion() + gramatica() + capturas() + manual(), onFirstPage=pie, onLaterPages=pie)
    print("Reporte generado:", SALIDA)
