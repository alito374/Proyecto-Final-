"""Ventana principal de TuzoLang IDE (PyQt6)."""
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction, QColor, QKeySequence
from PyQt6.QtWidgets import (QAbstractItemView, QFileDialog, QHeaderView, QLabel,
                             QMainWindow, QMessageBox, QSplitter, QTableWidget,
                             QTableWidgetItem, QTabWidget, QToolBar, QVBoxLayout, QWidget)

from lenguaje import Analizador
from .buscador import BarraBusqueda
from .editor import Editor
from .resaltador import Resaltador

NOMBRE_APP = "TuzoLang IDE"
CARPETA_EJEMPLOS = Path(__file__).resolve().parent.parent / "ejemplos"
FILTRO_ARCHIVOS = "Programas TuzoLang (*.tuzo);;Todos los archivos (*)"

COLORES_FILA = {
    "Léxico": "#ffd6d6", "Sintáctico": "#ffd6d6",
    "Semántico": "#ffe3c2", "Advertencia": "#fff6c9",
}

PLANTILLA = """programa MiPrograma {
    // Escribe tu código aquí
    guardar mensaje = "Hola, Tuzo";
    mostrar(mensaje);
}
"""


class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()
        self.analizador = Analizador()
        self.archivo_actual = None

        self.resize(1100, 780)
        self._crear_widgets()
        self._crear_acciones()
        self._crear_menus()
        self._crear_barra_herramientas()
        self._conectar_senales()
        self.editor.setPlainText(PLANTILLA)
        self.editor.document().setModified(False)
        self._actualizar_titulo()
        self._mostrar_banner("neutro", "Presiona F5 para analizar el código")

    # ================================================================ interfaz
    def _crear_widgets(self):
        self.editor = Editor()
        self.resaltador = Resaltador(self.editor.document())
        self.buscador = BarraBusqueda(self.editor)

        zona_editor = QWidget()
        lay = QVBoxLayout(zona_editor)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.editor)
        lay.addWidget(self.buscador)

        # banner de resultado
        self.banner = QLabel()
        self.banner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.banner.setMinimumHeight(40)

        # tabla de errores / advertencias
        self.tabla_errores = self._crear_tabla(["Tipo", "Línea", "Columna", "Descripción"])
        self.tabla_errores.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        # tabla de tokens
        self.tabla_tokens = self._crear_tabla(["#", "Token", "Lexema", "Línea", "Columna"])
        self.tabla_tokens.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        self.pestanas = QTabWidget()
        self.pestanas.addTab(self.tabla_errores, "Resultados del análisis")
        self.pestanas.addTab(self.tabla_tokens, "Tokens reconocidos")

        zona_resultados = QWidget()
        lay2 = QVBoxLayout(zona_resultados)
        lay2.setContentsMargins(0, 0, 0, 0)
        lay2.addWidget(self.banner)
        lay2.addWidget(self.pestanas)

        divisor = QSplitter(Qt.Orientation.Vertical)
        divisor.addWidget(zona_editor)
        divisor.addWidget(zona_resultados)
        divisor.setStretchFactor(0, 3)
        divisor.setStretchFactor(1, 2)
        self.setCentralWidget(divisor)

        self.lbl_posicion = QLabel("Ln 1, Col 1")
        self.statusBar().addPermanentWidget(self.lbl_posicion)
        self.statusBar().showMessage("Listo")

    @staticmethod
    def _crear_tabla(columnas):
        t = QTableWidget(0, len(columnas))
        t.setHorizontalHeaderLabels(columnas)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.verticalHeader().setVisible(False)
        t.setAlternatingRowColors(False)
        return t

    def _accion(self, texto, atajo=None, slot=None, tip=None):
        a = QAction(texto, self)
        if atajo is not None:
            a.setShortcut(QKeySequence(atajo))
        if tip:
            a.setStatusTip(tip)
        if slot:
            a.triggered.connect(slot)
        return a

    def _crear_acciones(self):
        SK = QKeySequence.StandardKey
        self.a_nuevo = self._accion("Nuevo", SK.New, self.nuevo, "Crear un programa nuevo")
        self.a_abrir = self._accion("Abrir...", SK.Open, self.abrir, "Abrir un archivo .tuzo")
        self.a_guardar = self._accion("Guardar", SK.Save, self.guardar)
        self.a_guardar_como = self._accion("Guardar como...", SK.SaveAs, self.guardar_como)
        self.a_salir = self._accion("Salir", "Ctrl+Q", self.close)

        self.a_deshacer = self._accion("Deshacer", SK.Undo, self.editor.undo)
        self.a_rehacer = self._accion("Rehacer", SK.Redo, self.editor.redo)
        self.a_cortar = self._accion("Cortar", SK.Cut, self.editor.cut)
        self.a_copiar = self._accion("Copiar", SK.Copy, self.editor.copy)
        self.a_pegar = self._accion("Pegar", SK.Paste, self.editor.paste)
        self.a_todo = self._accion("Seleccionar todo", SK.SelectAll, self.editor.selectAll)
        self.a_buscar = self._accion("Buscar...", SK.Find, lambda: self.buscador.mostrar(False))
        self.a_reemplazar = self._accion("Buscar y reemplazar...", "Ctrl+H",
                                         lambda: self.buscador.mostrar(True))

        self.a_analizar = self._accion("▶ Analizar", "F5", self.analizar,
                                       "Analiza el código del editor")
        self.a_acerca = self._accion("Acerca de", None, self.acerca_de)

        # estado inicial de las acciones dependientes de la selección / historial
        for a in (self.a_deshacer, self.a_rehacer, self.a_cortar, self.a_copiar):
            a.setEnabled(False)

    def _crear_menus(self):
        m = self.menuBar()
        archivo = m.addMenu("&Archivo")
        archivo.addActions([self.a_nuevo, self.a_abrir, self.a_guardar, self.a_guardar_como])
        archivo.addSeparator()
        archivo.addAction(self.a_salir)

        editar = m.addMenu("&Editar")
        editar.addActions([self.a_deshacer, self.a_rehacer])
        editar.addSeparator()
        editar.addActions([self.a_cortar, self.a_copiar, self.a_pegar, self.a_todo])
        editar.addSeparator()
        editar.addActions([self.a_buscar, self.a_reemplazar])

        ejecutar = m.addMenu("E&jecutar")
        ejecutar.addAction(self.a_analizar)

        ejemplos = m.addMenu("E&jemplos")
        if CARPETA_EJEMPLOS.exists():
            for ruta in sorted(CARPETA_EJEMPLOS.glob("*.tuzo")):
                act = QAction(ruta.name, self)
                act.triggered.connect(lambda _=False, r=ruta: self._abrir_ruta(str(r)))
                ejemplos.addAction(act)

        ayuda = m.addMenu("A&yuda")
        ayuda.addAction(self.a_acerca)

    def _crear_barra_herramientas(self):
        barra = QToolBar("Principal")
        barra.setMovable(False)
        self.addToolBar(barra)
        barra.addActions([self.a_nuevo, self.a_abrir, self.a_guardar])
        barra.addSeparator()
        barra.addActions([self.a_cortar, self.a_copiar, self.a_pegar])
        barra.addSeparator()
        barra.addActions([self.a_buscar, self.a_reemplazar])
        barra.addSeparator()
        barra.addAction(self.a_analizar)

    def _conectar_senales(self):
        self.editor.undoAvailable.connect(self.a_deshacer.setEnabled)
        self.editor.redoAvailable.connect(self.a_rehacer.setEnabled)
        self.editor.copyAvailable.connect(self.a_cortar.setEnabled)
        self.editor.copyAvailable.connect(self.a_copiar.setEnabled)
        self.editor.cursorPositionChanged.connect(self._actualizar_posicion)
        self.editor.document().modificationChanged.connect(lambda _: self._actualizar_titulo())
        self.tabla_errores.cellClicked.connect(self._ir_a_error)
        self.tabla_tokens.cellClicked.connect(self._ir_a_token)

    # ========================================================== análisis
    def analizar(self):
        try:
            resultado = self.analizador.analizar(self.editor.toPlainText())
        except Exception as exc:                       # error interno inesperado
            QMessageBox.critical(self, "Error interno", f"El analizador falló:\n{exc}")
            return
        self._mostrar_resultado(resultado)

    def _mostrar_resultado(self, res):
        # --- tabla de errores
        self.tabla_errores.setRowCount(0)
        marcas = {}
        for d in res.diagnosticos:
            fila = self.tabla_errores.rowCount()
            self.tabla_errores.insertRow(fila)
            for col, valor in enumerate((d.tipo, d.linea, d.columna, d.mensaje)):
                item = QTableWidgetItem(str(valor))
                item.setBackground(QColor(COLORES_FILA[d.tipo]))
                item.setForeground(QColor("#222222"))
                self.tabla_errores.setItem(fila, col, item)
            if marcas.get(d.linea) != "error":
                marcas[d.linea] = "error" if d.es_error else "advertencia"
        self.tabla_errores.resizeColumnsToContents()
        self.tabla_errores.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.editor.marcar_lineas(marcas)

        # --- tabla de tokens
        self.tabla_tokens.setRowCount(len(res.tokens))
        for i, (tipo, valor, linea, col) in enumerate(res.tokens):
            texto = f'"{valor}"' if tipo == "CADENA" else str(valor)
            for c, v in enumerate((i + 1, tipo, texto, linea, col)):
                self.tabla_tokens.setItem(i, c, QTableWidgetItem(str(v)))
        self.tabla_tokens.resizeColumnsToContents()
        self.tabla_tokens.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        # --- banner
        n_err, n_adv = len(res.errores), len(res.advertencias)
        extra = f"  ({n_adv} advertencia(s))" if n_adv else ""
        if res.valido:
            self._mostrar_banner("ok", f"✔ CÓDIGO VÁLIDO — sin errores léxicos, sintácticos ni semánticos{extra}")
        else:
            self._mostrar_banner("error", f"✘ CÓDIGO INVÁLIDO — {n_err} error(es) encontrado(s){extra}")
        self.pestanas.setCurrentIndex(0)
        self.statusBar().showMessage(
            f"Análisis terminado en {res.segundos * 1000:.1f} ms — {len(res.tokens)} tokens", 5000)

    def _mostrar_banner(self, estado, texto):
        colores = {"ok": ("#1e7e34", "#ffffff"), "error": ("#c62828", "#ffffff"),
                   "neutro": ("#e0e0e0", "#333333")}
        fondo, letra = colores[estado]
        self.banner.setText(texto)
        self.banner.setStyleSheet(
            f"background-color:{fondo}; color:{letra}; font-size:15px; font-weight:bold; border-radius:4px;")

    def _ir_a_error(self, fila, _col):
        linea = int(self.tabla_errores.item(fila, 1).text())
        columna = int(self.tabla_errores.item(fila, 2).text())
        self.editor.ir_a(linea, columna)

    def _ir_a_token(self, fila, _col):
        linea = int(self.tabla_tokens.item(fila, 3).text())
        columna = int(self.tabla_tokens.item(fila, 4).text())
        self.editor.ir_a(linea, columna)

    # ============================================================ archivos
    def _confirmar_descarte(self):
        """True si se puede continuar (guardó, descartó o no había cambios)."""
        if not self.editor.document().isModified():
            return True
        r = QMessageBox.question(
            self, NOMBRE_APP, "El programa tiene cambios sin guardar. ¿Deseas guardarlos?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
            | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Save:
            return self.guardar()
        return r == QMessageBox.StandardButton.Discard

    def nuevo(self):
        if self._confirmar_descarte():
            self.editor.setPlainText(PLANTILLA)
            self.archivo_actual = None
            self.editor.document().setModified(False)
            self._limpiar_resultados()
            self._actualizar_titulo()

    def abrir(self):
        if not self._confirmar_descarte():
            return
        ruta, _ = QFileDialog.getOpenFileName(self, "Abrir programa", "", FILTRO_ARCHIVOS)
        if ruta:
            self._abrir_ruta(ruta, confirmar=False)

    def _abrir_ruta(self, ruta, confirmar=True):
        if confirmar and not self._confirmar_descarte():
            return
        try:
            self.editor.setPlainText(Path(ruta).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError) as exc:
            QMessageBox.warning(self, NOMBRE_APP, f"No se pudo abrir el archivo:\n{exc}")
            return
        self.archivo_actual = ruta
        self.editor.document().setModified(False)
        self._limpiar_resultados()
        self._actualizar_titulo()

    def guardar(self):
        if self.archivo_actual is None:
            return self.guardar_como()
        return self._escribir(self.archivo_actual)

    def guardar_como(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar programa", "programa.tuzo", FILTRO_ARCHIVOS)
        if not ruta:
            return False
        if not Path(ruta).suffix:
            ruta += ".tuzo"
        return self._escribir(ruta)

    def _escribir(self, ruta):
        try:
            Path(ruta).write_text(self.editor.toPlainText(), encoding="utf-8")
        except OSError as exc:
            QMessageBox.warning(self, NOMBRE_APP, f"No se pudo guardar el archivo:\n{exc}")
            return False
        self.archivo_actual = ruta
        self.editor.document().setModified(False)
        self._actualizar_titulo()
        self.statusBar().showMessage(f"Guardado en {ruta}", 4000)
        return True

    def _limpiar_resultados(self):
        self.tabla_errores.setRowCount(0)
        self.tabla_tokens.setRowCount(0)
        self.editor.limpiar_marcas()
        self._mostrar_banner("neutro", "Presiona F5 para analizar el código")

    # ============================================================ varios
    def _actualizar_titulo(self):
        nombre = Path(self.archivo_actual).name if self.archivo_actual else "sin título"
        marca = "*" if self.editor.document().isModified() else ""
        self.setWindowTitle(f"{nombre}{marca} — {NOMBRE_APP}")

    def _actualizar_posicion(self):
        c = self.editor.textCursor()
        self.lbl_posicion.setText(f"Ln {c.blockNumber() + 1}, Col {c.columnNumber() + 1}")

    def acerca_de(self):
        QMessageBox.about(
            self, "Acerca de",
            f"<b>{NOMBRE_APP}</b><br>Editor y analizador del lenguaje <b>TuzoLang</b>.<br><br>"
            "Construido con Python, PyQt6 y PLY.")

    def closeEvent(self, evento):
        if self._confirmar_descarte():
            evento.accept()
        else:
            evento.ignore()
