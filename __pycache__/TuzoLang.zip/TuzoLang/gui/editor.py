"""Editor de código con numeración de líneas y marcado de errores."""
from PyQt6.QtCore import QRect, QSize, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QTextCursor, QTextFormat
from PyQt6.QtWidgets import QPlainTextEdit, QTextEdit, QWidget

COLOR_ERROR = QColor(255, 205, 205)
COLOR_ADVERTENCIA = QColor(255, 244, 195)
COLOR_LINEA_ACTUAL = QColor(235, 242, 255)


class _AreaNumeros(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.ancho_numeros(), 0)

    def paintEvent(self, event):
        self.editor.pintar_numeros(event)


class Editor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        fuente = QFont("Consolas")
        fuente.setStyleHint(QFont.StyleHint.Monospace)
        fuente.setPointSize(12)
        self.setFont(fuente)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self.setPlaceholderText("Escribe aquí tu programa en TuzoLang...")

        self._lineas_marcadas = {}          # número de línea -> "error" | "advertencia"
        self._area = _AreaNumeros(self)

        self.blockCountChanged.connect(self._actualizar_margen)
        self.updateRequest.connect(self._actualizar_area)
        self.cursorPositionChanged.connect(self._resaltar)
        self._actualizar_margen()
        self._resaltar()

    # ------------------------------------------------- numeración de líneas
    def ancho_numeros(self):
        digitos = len(str(max(1, self.blockCount())))
        return 16 + self.fontMetrics().horizontalAdvance("9") * digitos

    def _actualizar_margen(self, *_):
        self.setViewportMargins(self.ancho_numeros(), 0, 0, 0)

    def _actualizar_area(self, rect, dy):
        if dy:
            self._area.scroll(0, dy)
        else:
            self._area.update(0, rect.y(), self._area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._actualizar_margen()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._area.setGeometry(QRect(cr.left(), cr.top(), self.ancho_numeros(), cr.height()))

    def pintar_numeros(self, event):
        painter = QPainter(self._area)
        painter.fillRect(event.rect(), QColor(243, 243, 243))
        bloque = self.firstVisibleBlock()
        numero = bloque.blockNumber()
        top = round(self.blockBoundingGeometry(bloque).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(bloque).height())
        while bloque.isValid() and top <= event.rect().bottom():
            if bloque.isVisible() and bottom >= event.rect().top():
                tipo = self._lineas_marcadas.get(numero + 1)
                if tipo == "error":
                    painter.setPen(QColor(200, 0, 0))
                elif tipo == "advertencia":
                    painter.setPen(QColor(180, 120, 0))
                else:
                    painter.setPen(QColor(120, 120, 120))
                painter.drawText(0, top, self._area.width() - 6, self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight, str(numero + 1))
            bloque = bloque.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(bloque).height())
            numero += 1

    # --------------------------------------------------- resaltado de líneas
    def _resaltar(self):
        selecciones = []
        # línea actual
        actual = QTextEdit.ExtraSelection()
        actual.format.setBackground(COLOR_LINEA_ACTUAL)
        actual.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
        actual.cursor = self.textCursor()
        actual.cursor.clearSelection()
        selecciones.append(actual)
        # líneas con error / advertencia
        for linea, tipo in self._lineas_marcadas.items():
            bloque = self.document().findBlockByNumber(linea - 1)
            if not bloque.isValid():
                continue
            sel = QTextEdit.ExtraSelection()
            sel.format.setBackground(COLOR_ERROR if tipo == "error" else COLOR_ADVERTENCIA)
            sel.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            sel.cursor = QTextCursor(bloque)
            sel.cursor.clearSelection()
            selecciones.append(sel)
        self.setExtraSelections(selecciones)

    def marcar_lineas(self, lineas):
        """lineas: dict {número_de_línea: 'error' | 'advertencia'}"""
        self._lineas_marcadas = dict(lineas)
        self._resaltar()
        self._area.update()

    def limpiar_marcas(self):
        self.marcar_lineas({})

    def ir_a(self, linea, columna):
        """Lleva el cursor a (línea, columna) base 1 y enfoca el editor."""
        bloque = self.document().findBlockByNumber(max(0, linea - 1))
        cursor = QTextCursor(bloque)
        cursor.setPosition(bloque.position() + min(max(0, columna - 1), max(0, bloque.length() - 1)))
        self.setTextCursor(cursor)
        self.setFocus()
        self.centerCursor()
