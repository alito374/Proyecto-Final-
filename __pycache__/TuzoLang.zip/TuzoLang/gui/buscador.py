"""Barra de búsqueda y reemplazo (Ctrl+F / Ctrl+H)."""
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeySequence, QShortcut, QTextCursor, QTextDocument
from PyQt6.QtWidgets import (QCheckBox, QHBoxLayout, QLabel, QLineEdit,
                             QPushButton, QVBoxLayout, QWidget)


class BarraBusqueda(QWidget):
    def __init__(self, editor, parent=None):
        super().__init__(parent)
        self.editor = editor

        self.campo_buscar = QLineEdit(placeholderText="Buscar...")
        self.campo_reemplazar = QLineEdit(placeholderText="Reemplazar por...")
        self.chk_mayusculas = QCheckBox("Distinguir mayúsculas")
        self.lbl_estado = QLabel("")
        self.lbl_estado.setMinimumWidth(110)

        btn_ant = QPushButton("◀ Anterior")
        btn_sig = QPushButton("Siguiente ▶")
        btn_rep = QPushButton("Reemplazar")
        btn_todo = QPushButton("Reemplazar todo")
        btn_cerrar = QPushButton("✕")
        btn_cerrar.setFixedWidth(30)

        fila1 = QHBoxLayout()
        for w in (self.campo_buscar, btn_ant, btn_sig, self.chk_mayusculas, self.lbl_estado, btn_cerrar):
            fila1.addWidget(w)
        self.fila_reemplazo = QWidget()
        fila2 = QHBoxLayout(self.fila_reemplazo)
        fila2.setContentsMargins(0, 0, 0, 0)
        for w in (self.campo_reemplazar, btn_rep, btn_todo):
            fila2.addWidget(w)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.addLayout(fila1)
        layout.addWidget(self.fila_reemplazo)

        # conexiones
        self.campo_buscar.returnPressed.connect(lambda: self.buscar())
        self.campo_buscar.textChanged.connect(self._actualizar_conteo)
        self.chk_mayusculas.toggled.connect(self._actualizar_conteo)
        btn_sig.clicked.connect(lambda: self.buscar())
        btn_ant.clicked.connect(lambda: self.buscar(atras=True))
        btn_rep.clicked.connect(self.reemplazar)
        btn_todo.clicked.connect(self.reemplazar_todo)
        btn_cerrar.clicked.connect(self.ocultar)

        esc = QShortcut(QKeySequence("Esc"), self)
        esc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        esc.activated.connect(self.ocultar)

        self.setVisible(False)

    # ---------------------------------------------------------------- mostrar
    def mostrar(self, con_reemplazo=False):
        self.setVisible(True)
        self.fila_reemplazo.setVisible(con_reemplazo)
        seleccion = self.editor.textCursor().selectedText()
        if seleccion and "\u2029" not in seleccion:
            self.campo_buscar.setText(seleccion)
        self.campo_buscar.setFocus()
        self.campo_buscar.selectAll()
        self._actualizar_conteo()

    def ocultar(self):
        self.setVisible(False)
        self.editor.setFocus()

    # --------------------------------------------------------------- búsqueda
    def _opciones(self, atras=False):
        flags = QTextDocument.FindFlag(0)
        if self.chk_mayusculas.isChecked():
            flags |= QTextDocument.FindFlag.FindCaseSensitively
        if atras:
            flags |= QTextDocument.FindFlag.FindBackward
        return flags

    def buscar(self, atras=False):
        texto = self.campo_buscar.text()
        if not texto:
            return False
        flags = self._opciones(atras)
        encontrado = self.editor.find(texto, flags)
        if not encontrado:                                    # volver a empezar (búsqueda circular)
            cursor = self.editor.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End if atras
                                else QTextCursor.MoveOperation.Start)
            self.editor.setTextCursor(cursor)
            encontrado = self.editor.find(texto, flags)
        if not encontrado:
            self.lbl_estado.setText("Sin resultados")
        return encontrado

    def _actualizar_conteo(self, *_):
        texto = self.campo_buscar.text()
        if not texto:
            self.lbl_estado.setText("")
            return
        doc = self.editor.document()
        cursor = QTextCursor(doc)
        flags = self._opciones()
        total = 0
        while True:
            cursor = doc.find(texto, cursor, flags)
            if cursor.isNull():
                break
            total += 1
        self.lbl_estado.setText(f"{total} coincidencia(s)" if total else "Sin resultados")

    # ------------------------------------------------------------ reemplazar
    def reemplazar(self):
        texto = self.campo_buscar.text()
        cursor = self.editor.textCursor()
        if texto and cursor.hasSelection():
            sel, ref = cursor.selectedText(), texto
            if not self.chk_mayusculas.isChecked():
                sel, ref = sel.lower(), ref.lower()
            if sel == ref:
                cursor.insertText(self.campo_reemplazar.text())
        self.buscar()
        self._actualizar_conteo()

    def reemplazar_todo(self):
        texto = self.campo_buscar.text()
        if not texto:
            return
        doc = self.editor.document()
        edicion = QTextCursor(doc)
        edicion.beginEditBlock()
        busqueda = QTextCursor(doc)
        total = 0
        while True:
            busqueda = doc.find(texto, busqueda, self._opciones())
            if busqueda.isNull():
                break
            busqueda.insertText(self.campo_reemplazar.text())
            total += 1
        edicion.endEditBlock()
        self.lbl_estado.setText(f"{total} reemplazo(s)")
