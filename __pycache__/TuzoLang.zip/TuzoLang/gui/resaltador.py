"""Coloreado de sintaxis para el editor."""
import re

from PyQt6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat

from lenguaje.lexico import PALABRAS_RESERVADAS


def _formato(color, negrita=False, cursiva=False):
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if negrita:
        f.setFontWeight(QFont.Weight.Bold)
    f.setFontItalic(cursiva)
    return f


class Resaltador(QSyntaxHighlighter):
    def __init__(self, documento):
        super().__init__(documento)
        palabras = "|".join(sorted(PALABRAS_RESERVADAS, key=len, reverse=True))
        self._reglas = [
            (re.compile(r"\b\d+(\.\d+)?\b"), _formato("#b35c00")),                   # números
            (re.compile(rf"\b({palabras})\b"), _formato("#0033b3", negrita=True)),   # reservadas
            (re.compile(r'"([^"\\\n]|\\.)*"?'), _formato("#067d17")),                # cadenas
            (re.compile(r"//[^\n]*"), _formato("#808080", cursiva=True)),            # comentario de línea
        ]
        self._fmt_comentario = _formato("#808080", cursiva=True)

    def highlightBlock(self, texto):
        for patron, formato in self._reglas:
            for m in patron.finditer(texto):
                self.setFormat(m.start(), m.end() - m.start(), formato)

        # comentarios de bloque /* ... */ (pueden abarcar varias líneas)
        self.setCurrentBlockState(0)
        continuando = self.previousBlockState() == 1
        inicio = 0 if continuando else texto.find("/*")
        while inicio >= 0:
            fin = texto.find("*/", inicio if continuando else inicio + 2)
            if fin == -1:
                self.setCurrentBlockState(1)
                largo = len(texto) - inicio
            else:
                largo = fin + 2 - inicio
            self.setFormat(inicio, largo, self._fmt_comentario)
            if fin == -1:
                break
            continuando = False
            inicio = texto.find("/*", inicio + largo)
