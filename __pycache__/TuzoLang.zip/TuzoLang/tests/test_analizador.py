"""Pruebas del motor de análisis. Ejecutar:  python -m unittest discover -s tests -v"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from lenguaje import Analizador  # noqa: E402

EJEMPLOS = Path(__file__).resolve().parent.parent / "ejemplos"


class PruebasTuzoLang(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a = Analizador()

    def tipos(self, codigo):
        return {d.tipo for d in self.a.analizar(codigo).errores}

    def test_programa_minimo_valido(self):
        self.assertTrue(self.a.analizar("programa P { }").valido)

    def test_ejemplo_valido(self):
        res = self.a.analizar((EJEMPLOS / "valido.tuzo").read_text(encoding="utf-8"))
        self.assertTrue(res.valido, [str(d) for d in res.errores])

    def test_archivo_vacio(self):
        self.assertFalse(self.a.analizar("   \n").valido)

    def test_error_lexico(self):
        self.assertIn("Léxico", self.tipos("programa P { guardar x = 3 @ 4; }"))

    def test_cadena_sin_cerrar(self):
        self.assertIn("Léxico", self.tipos('programa P { mostrar("hola); }'))

    def test_falta_punto_y_coma(self):
        self.assertIn("Sintáctico", self.tipos("programa P { guardar x = 1 }"))

    def test_falta_llave_final(self):
        self.assertIn("Sintáctico", self.tipos("programa P { guardar x = 1;"))

    def test_variable_no_declarada(self):
        self.assertIn("Semántico", self.tipos("programa P { x = 1; }"))

    def test_redeclaracion(self):
        self.assertIn("Semántico", self.tipos("programa P { guardar x = 1; guardar x = 2; mostrar(x); }"))

    def test_tipos_incompatibles(self):
        self.assertIn("Semántico", self.tipos('programa P { guardar x = 1; x = "a"; mostrar(x); }'))

    def test_condicion_no_logica(self):
        self.assertIn("Semántico", self.tipos("programa P { si (1) { } }"))

    def test_division_entre_cero(self):
        self.assertIn("Semántico", self.tipos("programa P { mostrar(5 / 0); }"))

    def test_variable_sin_usar_es_advertencia(self):
        res = self.a.analizar("programa P { guardar x = 1; }")
        self.assertTrue(res.valido)
        self.assertEqual(len(res.advertencias), 1)

    def test_varios_errores_sintacticos(self):
        res = self.a.analizar("programa P {\n guardar a = ;\n guardar b = ;\n}")
        self.assertGreaterEqual(len(res.errores), 2)

    def test_posicion_del_error(self):
        res = self.a.analizar("programa P {\n  x = 1;\n}")
        self.assertEqual((res.errores[0].linea, res.errores[0].columna), (2, 3))


if __name__ == "__main__":
    unittest.main()
