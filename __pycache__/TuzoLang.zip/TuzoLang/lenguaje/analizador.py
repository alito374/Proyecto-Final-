"""Fachada del motor de análisis: une las tres fases y entrega un Resultado."""
import sys
import time
from dataclasses import dataclass, field

from .diagnostico import Diagnostico, SINTACTICO
from .lexico import TuzoLexer
from .semantico import Semantico
from .sintactico import TuzoParser


@dataclass
class Resultado:
    diagnosticos: list = field(default_factory=list)   # errores + advertencias
    tokens: list = field(default_factory=list)         # (tipo, valor, línea, columna)
    ast: object = None
    segundos: float = 0.0

    @property
    def errores(self):
        return [d for d in self.diagnosticos if d.es_error]

    @property
    def advertencias(self):
        return [d for d in self.diagnosticos if not d.es_error]

    @property
    def valido(self) -> bool:
        return not self.errores


class Analizador:
    def __init__(self):
        self.lexico = TuzoLexer()
        self.sintactico = TuzoParser(self.lexico)

    def analizar(self, codigo: str) -> Resultado:
        inicio = time.perf_counter()
        resultado = Resultado()

        if not codigo.strip():
            resultado.diagnosticos.append(Diagnostico(
                SINTACTICO, 1, 1,
                "El archivo está vacío: todo programa debe iniciar con 'programa Nombre { ... }'"))
            return resultado

        # 1) Fase léxica
        resultado.tokens, errores_lexicos = self.lexico.tokenizar(codigo)
        diagnosticos = list(errores_lexicos)

        # 2) Fase sintáctica
        resultado.ast = self.sintactico.parsear(codigo)
        errores_sintacticos = list(self.sintactico.errores)
        diagnosticos += errores_sintacticos

        # 3) Fase semántica (solo si el programa es léxica y sintácticamente correcto)
        if not errores_lexicos and not errores_sintacticos and resultado.ast is not None:
            diagnosticos += Semantico().analizar(resultado.ast)

        resultado.diagnosticos = sorted(diagnosticos, key=lambda d: (d.linea, d.columna))
        resultado.segundos = time.perf_counter() - inicio
        return resultado


if __name__ == "__main__":                       # uso por consola: python -m lenguaje.analizador archivo.tuzo
    if len(sys.argv) != 2:
        sys.exit("Uso: python -m lenguaje.analizador archivo.tuzo")
    with open(sys.argv[1], encoding="utf-8") as f:
        res = Analizador().analizar(f.read())
    for d in res.diagnosticos:
        print(d)
    print("\n✔ Código válido" if res.valido else f"\n✘ {len(res.errores)} error(es) encontrados")
    sys.exit(0 if res.valido else 1)
