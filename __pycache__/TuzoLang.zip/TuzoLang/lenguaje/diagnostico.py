"""Estructura común para reportar errores y advertencias."""
from dataclasses import dataclass

LEXICO = "Léxico"
SINTACTICO = "Sintáctico"
SEMANTICO = "Semántico"
ADVERTENCIA = "Advertencia"


@dataclass(frozen=True)
class Diagnostico:
    tipo: str        # Léxico | Sintáctico | Semántico | Advertencia
    linea: int
    columna: int
    mensaje: str

    @property
    def es_error(self) -> bool:
        return self.tipo != ADVERTENCIA

    def __str__(self) -> str:
        return f"[{self.tipo}] Línea {self.linea}, columna {self.columna}: {self.mensaje}"
