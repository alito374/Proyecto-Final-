"""
Análisis semántico de TuzoLang: recorre el AST y valida

  * variables declaradas / redeclaradas (con ámbitos por bloque)
  * compatibilidad de tipos (entero, decimal, texto, logico)
  * condiciones lógicas, división entre cero
  * advertencias: variables declaradas pero nunca usadas
"""
from .diagnostico import Diagnostico, SEMANTICO, ADVERTENCIA

NUMERICOS = ("entero", "decimal")
DESCONOCIDO = "?"          # variable declarada sin valor inicial


class Semantico:
    def __init__(self):
        self.diagnosticos = []
        self.ambitos = []

    # ------------------------------------------------------------ interfaz
    def analizar(self, programa):
        _, _nombre, sentencias, _pos = programa
        self._abrir()
        self._sentencias(sentencias)
        self._cerrar()
        return self.diagnosticos

    # --------------------------------------------------------------- ámbitos
    def _abrir(self):
        self.ambitos.append({})

    def _cerrar(self):
        ambito = self.ambitos.pop()
        for nombre, info in ambito.items():
            if not info["usada"]:
                self._reportar(ADVERTENCIA, info["pos"],
                               f"La variable '{nombre}' se declara pero nunca se usa")

    def _buscar(self, nombre):
        for ambito in reversed(self.ambitos):
            if nombre in ambito:
                return ambito[nombre]
        return None

    def _reportar(self, tipo, pos, mensaje):
        self.diagnosticos.append(Diagnostico(tipo, pos[0], pos[1], mensaje))

    def _error(self, pos, mensaje):
        self._reportar(SEMANTICO, pos, mensaje)

    # ------------------------------------------------------------ sentencias
    def _sentencias(self, lista):
        for s in lista:
            getattr(self, "_s_" + s[0])(s)

    def _bloque(self, lista):
        self._abrir()
        self._sentencias(lista)
        self._cerrar()

    def _s_declarar(self, s):
        _, nombre, expr, pos = s
        tipo = self._expr(expr) if expr is not None else DESCONOCIDO
        if nombre in self.ambitos[-1]:
            self._error(pos, f"La variable '{nombre}' ya fue declarada en este ámbito")
            return
        self.ambitos[-1][nombre] = {"tipo": tipo, "usada": False, "pos": pos}

    def _s_asignar(self, s):
        _, nombre, expr, pos = s
        tipo = self._expr(expr)
        info = self._buscar(nombre)
        if info is None:
            self._error(pos, f"La variable '{nombre}' no ha sido declarada (use 'guardar {nombre} = ...;')")
            return
        if info["tipo"] == DESCONOCIDO:
            info["tipo"] = tipo
        elif not self._compatible(info["tipo"], tipo):
            self._error(pos, f"No se puede asignar un valor '{tipo}' a la variable "
                             f"'{nombre}' de tipo '{info['tipo']}'")

    def _s_mostrar(self, s):
        for e in s[1]:
            self._expr(e)

    def _s_si(self, s):
        _, cond, bloque, sino, pos = s
        self._condicion(cond, "si")
        self._bloque(bloque)
        if sino is not None:
            self._bloque(sino)

    def _s_mientras(self, s):
        _, cond, bloque, pos = s
        self._condicion(cond, "mientras")
        self._bloque(bloque)

    def _s_repetir(self, s):
        _, var, ini, fin, bloque, pos = s
        for etiqueta, e in (("inicial", ini), ("final", fin)):
            t = self._expr(e)
            if t not in ("entero", DESCONOCIDO):
                self._error(self._pos_expr(e),
                            f"El valor {etiqueta} de 'repetir' debe ser entero, se obtuvo '{t}'")
        self._abrir()
        self.ambitos[-1][var] = {"tipo": "entero", "usada": True, "pos": pos}
        self._sentencias(bloque)
        self._cerrar()

    def _condicion(self, cond, palabra):
        t = self._expr(cond)
        if t not in ("logico", DESCONOCIDO):
            self._error(self._pos_expr(cond),
                        f"La condición de '{palabra}' debe ser lógica, se obtuvo '{t}'")

    # ----------------------------------------------------------- expresiones
    @staticmethod
    def _pos_expr(e):
        return e[-1]

    @staticmethod
    def _compatible(destino, origen):
        if DESCONOCIDO in (destino, origen) or destino == origen:
            return True
        return destino == "decimal" and origen == "entero"

    def _expr(self, e):
        return getattr(self, "_e_" + e[0])(e)

    def _e_num(self, e):
        return e[2]

    def _e_texto(self, e):
        return "texto"

    def _e_logico(self, e):
        return "logico"

    def _e_var(self, e):
        _, nombre, pos = e
        info = self._buscar(nombre)
        if info is None:
            self._error(pos, f"La variable '{nombre}' no ha sido declarada")
            return DESCONOCIDO
        info["usada"] = True
        return info["tipo"]

    def _e_un(self, e):
        _, op, sub, pos = e
        t = self._expr(sub)
        if op == "-":
            if t in NUMERICOS or t == DESCONOCIDO:
                return t
            self._error(pos, f"El operador '-' no se puede aplicar a '{t}'")
            return DESCONOCIDO
        if t not in ("logico", DESCONOCIDO):                       # op == "no"
            self._error(pos, f"El operador 'no' requiere un valor lógico, se obtuvo '{t}'")
        return "logico"

    def _e_bin(self, e):
        _, op, izq, der, pos = e
        ti, td = self._expr(izq), self._expr(der)
        ambos = (ti, td)

        if op in ("y", "o"):
            for t in ambos:
                if t not in ("logico", DESCONOCIDO):
                    self._error(pos, f"El operador '{op}' requiere valores lógicos, se obtuvo '{t}'")
                    break
            return "logico"

        if op in ("==", "!="):
            if not (DESCONOCIDO in ambos or ti == td or (ti in NUMERICOS and td in NUMERICOS)):
                self._error(pos, f"No se pueden comparar '{ti}' y '{td}' con '{op}'")
            return "logico"

        if op in ("<", ">", "<=", ">="):
            if not all(t in NUMERICOS or t == DESCONOCIDO for t in ambos):
                self._error(pos, f"El operador '{op}' requiere números, se obtuvo '{ti}' y '{td}'")
            return "logico"

        # ---- aritméticos
        if op == "+" and "texto" in ambos:
            return "texto"                                           # concatenación
        if not all(t in NUMERICOS or t == DESCONOCIDO for t in ambos):
            self._error(pos, f"El operador '{op}' no se puede aplicar a '{ti}' y '{td}'")
            return DESCONOCIDO
        if op in ("/", "%") and der[0] == "num" and der[1] == 0:
            self._error(pos, "División entre cero" if op == "/" else "Módulo entre cero")
        if DESCONOCIDO in ambos:
            return DESCONOCIDO
        if op == "/":
            return "decimal"
        return "decimal" if "decimal" in ambos else "entero"
