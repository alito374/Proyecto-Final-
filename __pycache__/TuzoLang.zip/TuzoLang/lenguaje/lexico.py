"""
Analizador léxico de TuzoLang (PLY - lex).

Define los TOKENS y sus EXPRESIONES REGULARES.
"""
import ply.lex as lex

from .diagnostico import Diagnostico, LEXICO

# --------------------------------------------------------------------------
# Palabras reservadas (lexema -> nombre del token)
# --------------------------------------------------------------------------
PALABRAS_RESERVADAS = {
    "programa": "PROGRAMA",
    "guardar": "GUARDAR",
    "mostrar": "MOSTRAR",
    "si": "SI",
    "sino": "SINO",
    "mientras": "MIENTRAS",
    "repetir": "REPETIR",
    "desde": "DESDE",
    "hasta": "HASTA",
    "verdadero": "VERDADERO",
    "falso": "FALSO",
    "y": "Y",
    "o": "O",
    "no": "NO",
}


def calcular_columna(datos: str, posicion: int) -> int:
    """Convierte una posición absoluta del texto en número de columna (base 1)."""
    ultimo_salto = datos.rfind("\n", 0, posicion)
    return posicion - ultimo_salto


class TuzoLexer:
    # ---------------------------------------------------------------- tokens
    tokens = [
        # literales e identificadores
        "ID", "ENTERO", "DECIMAL", "CADENA",
        # aritméticos
        "MAS", "MENOS", "POR", "DIV", "MOD",
        # comparación
        "IGUALIGUAL", "DIFERENTE", "MENORIGUAL", "MAYORIGUAL", "MENOR", "MAYOR",
        # asignación y signos
        "ASIGNA", "PUNTOCOMA", "COMA",
        "LPAREN", "RPAREN", "LLAVEIZQ", "LLAVEDER",
    ] + list(PALABRAS_RESERVADAS.values())

    # Caracteres que se ignoran entre tokens
    t_ignore = " \t\r"

    # ------------------------------------------- operadores y signos simples
    t_IGUALIGUAL = r"=="
    t_DIFERENTE = r"!="
    t_MENORIGUAL = r"<="
    t_MAYORIGUAL = r">="
    t_MENOR = r"<"
    t_MAYOR = r">"
    t_ASIGNA = r"="
    t_MAS = r"\+"
    t_MENOS = r"-"
    t_POR = r"\*"
    t_DIV = r"/"
    t_MOD = r"%"
    t_PUNTOCOMA = r";"
    t_COMA = r","
    t_LPAREN = r"\("
    t_RPAREN = r"\)"
    t_LLAVEIZQ = r"\{"
    t_LLAVEDER = r"\}"

    def __init__(self):
        self.errores = []
        self.registrar = True
        self.lexer = lex.lex(module=self)

    # --------------------------------------------- reglas con función (orden!)
    def t_COMENTARIO_BLOQUE(self, t):
        r"/\*[\s\S]*?\*/"
        t.lexer.lineno += t.value.count("\n")          # se descarta

    def t_COMENTARIO_SIN_CERRAR(self, t):
        r"/\*[\s\S]*"
        self._error(t, "Comentario de bloque sin cerrar (falta '*/')")
        t.lexer.lineno += t.value.count("\n")

    def t_COMENTARIO_LINEA(self, t):
        r"//[^\n]*"
        # se descarta

    def t_DECIMAL(self, t):
        r"\d+\.\d+"
        t.value = float(t.value)
        return t

    def t_ENTERO(self, t):
        r"\d+"
        t.value = int(t.value)
        return t

    def t_CADENA(self, t):
        r'"([^"\\\n]|\\.)*"'
        t.value = t.value[1:-1]
        return t

    def t_CADENA_SIN_CERRAR(self, t):
        r'"[^"\n]*'
        self._error(t, "Cadena de texto sin cerrar (falta la comilla de cierre)")

    def t_ID(self, t):
        r"[^\W\d]\w*"
        t.type = PALABRAS_RESERVADAS.get(t.value, "ID")
        return t

    def t_NUEVA_LINEA(self, t):
        r"\n+"
        t.lexer.lineno += len(t.value)

    def t_error(self, t):
        self._error(t, f"Carácter no reconocido '{t.value[0]}'")
        t.lexer.skip(1)

    # ------------------------------------------------------------ utilidades
    def _error(self, t, mensaje):
        if self.registrar:
            col = calcular_columna(t.lexer.lexdata, t.lexpos)
            self.errores.append(Diagnostico(LEXICO, t.lineno, col, mensaje))

    @property
    def datos(self) -> str:
        return self.lexer.lexdata

    def reiniciar(self, codigo: str, registrar: bool = True):
        """Prepara el lexer para analizar un nuevo texto."""
        self.errores = []
        self.registrar = registrar
        self.lexer.lineno = 1
        self.lexer.input(codigo)

    def tokenizar(self, codigo: str):
        """Devuelve (lista_de_tokens, errores_léxicos).

        Cada token es una tupla (tipo, valor, linea, columna).
        """
        self.reiniciar(codigo, registrar=True)
        lista = []
        while True:
            tok = self.lexer.token()
            if tok is None:
                break
            lista.append((tok.type, tok.value, tok.lineno,
                          calcular_columna(codigo, tok.lexpos)))
        return lista, list(self.errores)
