"""
Analizador sintáctico de TuzoLang (PLY - yacc).

Define la GRAMÁTICA (producciones) y construye el AST como tuplas.

Nodos del AST:
  ('programa', nombre, [sentencias], pos)
  ('declarar', nombre, expr|None, pos)
  ('asignar', nombre, expr, pos)
  ('mostrar', [exprs], pos)
  ('si', cond, [bloque], [bloque_sino]|None, pos)
  ('mientras', cond, [bloque], pos)
  ('repetir', var, ini, fin, [bloque], pos)
Expresiones:
  ('num', valor, 'entero'|'decimal', pos)   ('texto', valor, pos)
  ('logico', bool, pos)                      ('var', nombre, pos)
  ('bin', op, izq, der, pos)                 ('un', op, expr, pos)
donde pos = (linea, columna)
"""
import ply.yacc as yacc

from .diagnostico import Diagnostico, SINTACTICO
from .lexico import TuzoLexer, PALABRAS_RESERVADAS, calcular_columna

# Nombres legibles para los mensajes de error
_LEGIBLE = {
    "ID": "un identificador", "ENTERO": "un número entero",
    "DECIMAL": "un número decimal", "CADENA": "un texto entre comillas",
    "MAS": "'+'", "MENOS": "'-'", "POR": "'*'", "DIV": "'/'", "MOD": "'%'",
    "IGUALIGUAL": "'=='", "DIFERENTE": "'!='", "MENORIGUAL": "'<='",
    "MAYORIGUAL": "'>='", "MENOR": "'<'", "MAYOR": "'>'", "ASIGNA": "'='",
    "PUNTOCOMA": "';'", "COMA": "','", "LPAREN": "'('", "RPAREN": "')'",
    "LLAVEIZQ": "'{'", "LLAVEDER": "'}'",
}
_LEGIBLE.update({tok: f"'{lex}'" for lex, tok in PALABRAS_RESERVADAS.items()})


class TuzoParser:
    tokens = TuzoLexer.tokens
    start = "programa"

    # Precedencia: de MENOR a MAYOR prioridad
    precedence = (
        ("left", "O"),
        ("left", "Y"),
        ("right", "NO"),
        ("nonassoc", "IGUALIGUAL", "DIFERENTE"),
        ("nonassoc", "MENOR", "MAYOR", "MENORIGUAL", "MAYORIGUAL"),
        ("left", "MAS", "MENOS"),
        ("left", "POR", "DIV", "MOD"),
        ("right", "UMENOS"),
    )

    def __init__(self, lexico: TuzoLexer):
        self.lexico = lexico
        self.errores = []
        self.parser = yacc.yacc(module=self, debug=False, write_tables=False)

    def parsear(self, codigo: str):
        """Analiza el código y devuelve el AST (o None si no pudo construirse)."""
        self.errores = []
        self.lexico.reiniciar(codigo, registrar=False)   # los errores léxicos ya se reportaron
        return self.parser.parse(codigo, lexer=self.lexico.lexer)

    # ------------------------------------------------------------ utilidades
    def _pos(self, p, n):
        return (p.lineno(n), calcular_columna(self.lexico.datos, p.lexpos(n)))

    # =====================================================================
    #                              GRAMÁTICA
    # =====================================================================
    def p_programa(self, p):
        "programa : PROGRAMA ID LLAVEIZQ sentencias LLAVEDER"
        p[0] = ("programa", p[2], p[4], self._pos(p, 2))

    def p_sentencias_lista(self, p):
        "sentencias : sentencias sentencia"
        p[0] = p[1] + ([p[2]] if p[2] is not None else [])

    def p_sentencias_vacia(self, p):
        "sentencias :"
        p[0] = []

    def p_sentencia(self, p):
        """sentencia : declaracion
                     | asignacion
                     | impresion
                     | condicional
                     | ciclo_mientras
                     | ciclo_repetir"""
        p[0] = p[1]

    def p_sentencia_error(self, p):
        "sentencia : error PUNTOCOMA"          # recuperación de errores (modo pánico)
        p[0] = None

    # ---- sentencias simples
    def p_declaracion_valor(self, p):
        "declaracion : GUARDAR ID ASIGNA expresion PUNTOCOMA"
        p[0] = ("declarar", p[2], p[4], self._pos(p, 2))

    def p_declaracion_vacia(self, p):
        "declaracion : GUARDAR ID PUNTOCOMA"
        p[0] = ("declarar", p[2], None, self._pos(p, 2))

    def p_asignacion(self, p):
        "asignacion : ID ASIGNA expresion PUNTOCOMA"
        p[0] = ("asignar", p[1], p[3], self._pos(p, 1))

    def p_impresion(self, p):
        "impresion : MOSTRAR LPAREN lista_expresiones RPAREN PUNTOCOMA"
        p[0] = ("mostrar", p[3], self._pos(p, 1))

    def p_lista_expresiones_varias(self, p):
        "lista_expresiones : lista_expresiones COMA expresion"
        p[0] = p[1] + [p[3]]

    def p_lista_expresiones_una(self, p):
        "lista_expresiones : expresion"
        p[0] = [p[1]]

    # ---- estructuras de control
    def p_bloque(self, p):
        "bloque : LLAVEIZQ sentencias LLAVEDER"
        p[0] = p[2]

    def p_condicional_simple(self, p):
        "condicional : SI LPAREN expresion RPAREN bloque"
        p[0] = ("si", p[3], p[5], None, self._pos(p, 1))

    def p_condicional_sino(self, p):
        "condicional : SI LPAREN expresion RPAREN bloque SINO bloque"
        p[0] = ("si", p[3], p[5], p[7], self._pos(p, 1))

    def p_condicional_sino_si(self, p):
        "condicional : SI LPAREN expresion RPAREN bloque SINO condicional"
        p[0] = ("si", p[3], p[5], [p[7]], self._pos(p, 1))

    def p_ciclo_mientras(self, p):
        "ciclo_mientras : MIENTRAS LPAREN expresion RPAREN bloque"
        p[0] = ("mientras", p[3], p[5], self._pos(p, 1))

    def p_ciclo_repetir(self, p):
        "ciclo_repetir : REPETIR ID DESDE expresion HASTA expresion bloque"
        p[0] = ("repetir", p[2], p[4], p[6], p[7], self._pos(p, 1))

    # ---- expresiones
    def p_expresion_binaria(self, p):
        """expresion : expresion MAS expresion
                     | expresion MENOS expresion
                     | expresion POR expresion
                     | expresion DIV expresion
                     | expresion MOD expresion
                     | expresion IGUALIGUAL expresion
                     | expresion DIFERENTE expresion
                     | expresion MENOR expresion
                     | expresion MAYOR expresion
                     | expresion MENORIGUAL expresion
                     | expresion MAYORIGUAL expresion
                     | expresion Y expresion
                     | expresion O expresion"""
        p[0] = ("bin", p[2], p[1], p[3], self._pos(p, 2))

    def p_expresion_no(self, p):
        "expresion : NO expresion"
        p[0] = ("un", "no", p[2], self._pos(p, 1))

    def p_expresion_menos_unario(self, p):
        "expresion : MENOS expresion %prec UMENOS"
        p[0] = ("un", "-", p[2], self._pos(p, 1))

    def p_expresion_grupo(self, p):
        "expresion : LPAREN expresion RPAREN"
        p[0] = p[2]

    def p_expresion_entero(self, p):
        "expresion : ENTERO"
        p[0] = ("num", p[1], "entero", self._pos(p, 1))

    def p_expresion_decimal(self, p):
        "expresion : DECIMAL"
        p[0] = ("num", p[1], "decimal", self._pos(p, 1))

    def p_expresion_cadena(self, p):
        "expresion : CADENA"
        p[0] = ("texto", p[1], self._pos(p, 1))

    def p_expresion_logico(self, p):
        """expresion : VERDADERO
                     | FALSO"""
        p[0] = ("logico", p[1] == "verdadero", self._pos(p, 1))

    def p_expresion_variable(self, p):
        "expresion : ID"
        p[0] = ("var", p[1], self._pos(p, 1))

    # =====================================================================
    #                         MANEJO DE ERRORES
    # =====================================================================
    def _esperados(self):
        """Tokens que habría aceptado el parser en el estado actual."""
        try:
            estado = self.parser.statestack[-1]
            nombres = []
            for tok in self.parser.action[estado]:
                if tok in ("error", "$end"):
                    continue
                legible = _LEGIBLE.get(tok, tok)
                if legible not in nombres:
                    nombres.append(legible)
            return nombres
        except Exception:
            return []

    def p_error(self, p):
        if p is None:
            # Fin de archivo inesperado. Si ya hubo errores, es casi seguro
            # una consecuencia de ellos, así que no se repite.
            if not self.errores:
                datos = self.lexico.datos
                linea = datos.count("\n") + 1
                columna = len(datos.rsplit("\n", 1)[-1]) + 1
                self.errores.append(Diagnostico(
                    SINTACTICO, linea, columna,
                    "Fin de archivo inesperado: falta cerrar una llave '}' o terminar la sentencia"))
            return

        linea = p.lineno
        columna = calcular_columna(self.lexico.datos, p.lexpos)
        encontrado = _LEGIBLE.get(p.type, p.type)
        if p.type in ("ID", "ENTERO", "DECIMAL", "CADENA"):
            encontrado = f"{encontrado} ({p.value!r})"
        mensaje = f"Token inesperado: {encontrado}"

        esperados = self._esperados()
        if esperados and len(esperados) <= 6:
            mensaje += ". Se esperaba: " + ", ".join(esperados)
        self.errores.append(Diagnostico(SINTACTICO, linea, columna, mensaje))
