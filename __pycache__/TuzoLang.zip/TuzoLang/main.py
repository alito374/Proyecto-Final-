"""Punto de entrada: python main.py"""
import sys

from PyQt6.QtWidgets import QApplication

from gui.ventana import VentanaPrincipal


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
