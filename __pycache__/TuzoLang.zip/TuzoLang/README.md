# TuzoLang IDE

Lenguaje de programación propio (`.tuzo`) con editor de texto en **PyQt6** y motor de análisis
léxico, sintáctico y semántico en **PLY**.

## El lenguaje en 30 segundos

```tuzo
programa Ejemplo {
    guardar edad = 20;                  // variable
    mostrar("Edad: ", edad);            // salida

    si (edad >= 18 y no falso) {        // condicional
        mostrar("Mayor de edad");
    } sino {
        mostrar("Menor de edad");
    }

    repetir i desde 1 hasta 5 {         // ciclo con contador
        mostrar(i * 2);
    }

    mientras (edad < 25) {              // ciclo condicional
        edad = edad + 1;
    }
}
```

| Elemento | Regla |
|---|---|
| Estructura | Todo programa es `programa Nombre { ... }` |
| Variables | `guardar x = valor;` o `guardar x;` — el tipo se infiere del valor |
| Tipos | `entero`, `decimal`, `texto` (`"..."`), `logico` (`verdadero` / `falso`) |
| Operadores | `+ - * / %`, `== != < > <= >=`, `y`, `o`, `no` |
| Control | `si (...) {...} sino si (...) {...} sino {...}`, `mientras`, `repetir v desde a hasta b` |
| Salida | `mostrar(expr, expr, ...);` |
| Comentarios | `// línea` y `/* bloque */` |

## Instalación

```bash
git clone <URL-DEL-REPOSITORIO>
cd TuzoLang
python -m venv .venv
# Windows:  .venv\Scripts\activate        Linux/macOS:  source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Requiere Python 3.9 o superior.

## Uso del editor

| Acción | Atajo |
|---|---|
| Nuevo / Abrir / Guardar | Ctrl+N / Ctrl+O / Ctrl+S |
| Cortar / Copiar / Pegar | Ctrl+X / Ctrl+C / Ctrl+V |
| Deshacer / Rehacer | Ctrl+Z / Ctrl+Y |
| Buscar | Ctrl+F |
| Buscar y reemplazar | Ctrl+H |
| **Analizar el código** | **F5** |

Tras analizar, el banner indica si el código es **válido** o **inválido**; la tabla muestra tipo,
línea, columna y descripción de cada error (clic en una fila para saltar a esa posición) y la
pestaña *Tokens reconocidos* lista la salida del analizador léxico. El menú **Ejemplos** carga
programas válidos e inválidos de la carpeta `ejemplos/`.

## Estructura

```
main.py                 punto de entrada
lenguaje/lexico.py      tokens y expresiones regulares (PLY lex)
lenguaje/sintactico.py  gramática y producciones (PLY yacc)
lenguaje/semantico.py   variables, tipos y advertencias
lenguaje/analizador.py  une las tres fases
gui/                    editor, resaltado, búsqueda y ventana principal
ejemplos/               programas .tuzo de prueba
tests/                  pruebas unitarias
generar_reporte.py      genera Reporte_EquipoX.pdf
```

## Pruebas por consola

```bash
python -m unittest discover -s tests -v
python -m lenguaje.analizador ejemplos/valido.tuzo
```
