"""
Analizador léxico del lenguaje NOPAL (PLY - lex).

Define los tokens, sus expresiones regulares y el manejo de errores léxicos.
"""
import sys
import ply.lex as lex

from .errores import ErrorAnalisis, linea_columna

# ----------------------------------------------------------------------------
# Palabras reservadas
# ----------------------------------------------------------------------------
RESERVADAS = {
    "sembrar": "SEMBRAR",      # declara una variable
    "fijar": "FIJAR",          # declara una constante
    "decir": "DECIR",          # imprime valores
    "si": "SI",
    "sino": "SINO",
    "mientras": "MIENTRAS",
    "repetir": "REPETIR",
    "desde": "DESDE",
    "hasta": "HASTA",
    "cierto": "CIERTO",
    "falso": "FALSO",
    "y": "Y",
    "o": "O",
    "no": "NO",
}

tokens = [
    "ID", "NUMERO", "TEXTO",
    # operadores aritméticos
    "MAS", "MENOS", "POR", "DIV", "MOD", "POT",
    # operadores de comparación
    "IGUALIGUAL", "DIFERENTE", "MENORQUE", "MAYORQUE", "MENORIGUAL", "MAYORIGUAL",
    # asignación y delimitadores
    "IGUAL", "PARIZQ", "PARDER", "LLAVEIZQ", "LLAVEDER", "PUNTOCOMA", "COMA",
] + list(RESERVADAS.values())

# ----------------------------------------------------------------------------
# Tokens simples (PLY ordena las cadenas de mayor a menor longitud de regex,
# por eso '==' se reconoce antes que '=')
# ----------------------------------------------------------------------------
t_MAS = r"\+"
t_MENOS = r"-"
t_POR = r"\*"
t_DIV = r"/"
t_MOD = r"%"
t_POT = r"\^"
t_IGUALIGUAL = r"=="
t_DIFERENTE = r"!="
t_MENORIGUAL = r"<="
t_MAYORIGUAL = r">="
t_MENORQUE = r"<"
t_MAYORQUE = r">"
t_IGUAL = r"="
t_PARIZQ = r"\("
t_PARDER = r"\)"
t_LLAVEIZQ = r"\{"
t_LLAVEDER = r"\}"
t_PUNTOCOMA = r";"
t_COMA = r","

t_ignore = " \t\r"


# ----------------------------------------------------------------------------
# Tokens con función (el orden de definición es el orden de prioridad)
# ----------------------------------------------------------------------------
def t_COMENTARIO_BLOQUE(t):
    r"~\*[\s\S]*?\*~"
    pass  # se descarta


def t_COMENTARIO_SIN_CERRAR(t):
    r"~\*[\s\S]*"
    t.lexer.errores.append(ErrorAnalisis(
        "Léxico", *linea_columna(t.lexer.lexdata, t.lexpos),
        "Comentario de bloque sin cerrar (falta '*~')"))


def t_COMENTARIO_LINEA(t):
    r"~(?!\*)[^\n]*"
    pass  # se descarta


def t_NUMERO(t):
    r"\d+(\.\d+)?"
    return t


def t_TEXTO(t):
    r'"([^"\\\n]|\\.)*"'
    return t


def t_TEXTO_SIN_CERRAR(t):
    r'"([^"\\\n]|\\.)*'
    t.lexer.errores.append(ErrorAnalisis(
        "Léxico", *linea_columna(t.lexer.lexdata, t.lexpos),
        "Cadena de texto sin cerrar (falta '\"')"))


def t_ID(t):
    r"[A-Za-z_áéíóúüñÁÉÍÓÚÜÑ][A-Za-z0-9_áéíóúüñÁÉÍÓÚÜÑ]*"
    t.type = RESERVADAS.get(t.value, "ID")
    return t


def t_nueva_linea(t):
    r"\n+"
    pass


def t_error(t):
    t.lexer.errores.append(ErrorAnalisis(
        "Léxico", *linea_columna(t.lexer.lexdata, t.lexpos),
        f"Carácter no reconocido: {t.value[0]!r}"))
    t.lexer.skip(1)


# ----------------------------------------------------------------------------
# API
# ----------------------------------------------------------------------------
def construir_lexer():
    """Crea un lexer nuevo, con su propia lista de errores."""
    lexer = lex.lex(module=sys.modules[__name__])
    lexer.errores = []
    return lexer


def tokenizar(fuente: str):
    """Devuelve (lista_de_tokens, lista_de_errores_léxicos).

    Cada token es una tupla (tipo, lexema, línea, columna).
    """
    lexer = construir_lexer()
    lexer.input(fuente)
    resultado = []
    for tok in lexer:
        linea, col = linea_columna(fuente, tok.lexpos)
        resultado.append((tok.type, str(tok.value), linea, col))
    return resultado, lexer.errores
