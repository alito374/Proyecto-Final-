"""Widget de edición de código: números de línea, resaltado de línea/errores y sintaxis."""
from PyQt6.QtCore import Qt, QRect, QSize, QRegularExpression
from PyQt6.QtGui import (QColor, QPainter, QTextFormat, QTextCursor, QFont,
                         QSyntaxHighlighter, QTextCharFormat)
from PyQt6.QtWidgets import QPlainTextEdit, QWidget, QTextEdit


class _AreaNumeros(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.ancho_numeros(), 0)

    def paintEvent(self, event):
        self.editor.pintar_numeros(event)


class EditorCodigo(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lineas_error = set()
        self.area = _AreaNumeros(self)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self.setStyleSheet("QPlainTextEdit { background:#1e1f22; color:#d4d4d4; "
                           "selection-background-color:#264f78; }")

        self.blockCountChanged.connect(self._actualizar_margen)
        self.updateRequest.connect(self._actualizar_area)
        self.cursorPositionChanged.connect(self.resaltar)
        self._actualizar_margen(0)
        self.resaltar()

    # --- fuente -------------------------------------------------------------
    def establecer_fuente(self, fuente: QFont):
        self.setFont(fuente)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self._actualizar_margen(0)

    # --- números de línea ---------------------------------------------------
    def ancho_numeros(self):
        digitos = len(str(max(1, self.blockCount())))
        return 16 + self.fontMetrics().horizontalAdvance("9") * digitos

    def _actualizar_margen(self, _):
        self.setViewportMargins(self.ancho_numeros(), 0, 0, 0)

    def _actualizar_area(self, rect, dy):
        if dy:
            self.area.scroll(0, dy)
        else:
            self.area.update(0, rect.y(), self.area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._actualizar_margen(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.area.setGeometry(QRect(cr.left(), cr.top(), self.ancho_numeros(), cr.height()))

    def pintar_numeros(self, event):
        pintor = QPainter(self.area)
        pintor.fillRect(event.rect(), QColor("#2b2d30"))
        bloque = self.firstVisibleBlock()
        n = bloque.blockNumber()
        top = round(self.blockBoundingGeometry(bloque).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(bloque).height())
        alto = self.fontMetrics().height()
        while bloque.isValid() and top <= event.rect().bottom():
            if bloque.isVisible() and bottom >= event.rect().top():
                pintor.setPen(QColor("#ff6b6b") if (n + 1) in self.lineas_error
                              else QColor("#7f848e"))
                pintor.drawText(0, top, self.area.width() - 8, alto,
                                Qt.AlignmentFlag.AlignRight, str(n + 1))
            bloque = bloque.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(bloque).height())
            n += 1

    # --- resaltado de línea actual y líneas con error ----------------------
    def marcar_errores(self, lineas):
        self.lineas_error = set(lineas)
        self.resaltar()
        self.area.update()

    def resaltar(self):
        selecciones = []
        for linea in sorted(self.lineas_error):
            bloque = self.document().findBlockByNumber(linea - 1)
            if not bloque.isValid():
                continue
            sel = QTextEdit.ExtraSelection()
            sel.format.setBackground(QColor(88, 32, 32))
            sel.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            sel.cursor = QTextCursor(bloque)
            selecciones.append(sel)
        if not self.isReadOnly():
            actual = QTextEdit.ExtraSelection()
            actual.format.setBackground(QColor(255, 255, 255, 14))
            actual.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            actual.cursor = self.textCursor()
            actual.cursor.clearSelection()
            selecciones.append(actual)
        self.setExtraSelections(selecciones)


class ResaltadorNopal(QSyntaxHighlighter):
    """Colorea palabras reservadas, números, textos, operadores y comentarios."""

    def __init__(self, documento):
        super().__init__(documento)

        def fmt(color, negrita=False, cursiva=False):
            f = QTextCharFormat()
            f.setForeground(QColor(color))
            if negrita:
                f.setFontWeight(QFont.Weight.Bold)
            f.setFontItalic(cursiva)
            return f

        self.f_comentario = fmt("#6a9955", cursiva=True)
        self.reglas = [
            (r"[+\-*/%^=<>!]+", fmt("#d4d4d4")),
            (r"\b(sembrar|fijar|decir|si|sino|mientras|repetir|desde|hasta)\b",
             fmt("#c586c0", negrita=True)),
            (r"\b(cierto|falso)\b", fmt("#569cd6", negrita=True)),
            (r"\b(y|o|no)\b", fmt("#4ec9b0", negrita=True)),
            (r"\b\d+(\.\d+)?\b", fmt("#b5cea8")),
            (r'"([^"\\\n]|\\.)*"?', fmt("#ce9178")),
            (r"~(?!\*).*", self.f_comentario),
        ]
        self.reglas = [(QRegularExpression(p), f) for p, f in self.reglas]

    def highlightBlock(self, texto):
        for regex, formato in self.reglas:
            it = regex.globalMatch(texto)
            while it.hasNext():
                m = it.next()
                self.setFormat(m.capturedStart(), m.capturedLength(), formato)

        # comentarios de bloque  ~* ... *~  (pueden ocupar varias líneas)
        self.setCurrentBlockState(0)
        continua = self.previousBlockState() == 1
        inicio = 0 if continua else texto.find("~*")
        buscar_desde = 0 if continua else inicio + 2
        while inicio >= 0:
            fin = texto.find("*~", buscar_desde)
            if fin == -1:
                self.setCurrentBlockState(1)
                self.setFormat(inicio, len(texto) - inicio, self.f_comentario)
                break
            self.setFormat(inicio, fin + 2 - inicio, self.f_comentario)
            inicio = texto.find("~*", fin + 2)
            buscar_desde = inicio + 2
