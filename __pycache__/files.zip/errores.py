"""Estructuras y utilidades comunes a todas las fases del análisis."""
from dataclasses import dataclass


@dataclass
class ErrorAnalisis:
    tipo: str      # "Léxico", "Sintáctico" o "Semántico"
    linea: int
    columna: int
    mensaje: str


def linea_columna(fuente: str, pos: int):
    """Convierte una posición absoluta (lexpos) en (línea, columna), base 1."""
    pos = max(0, min(pos, len(fuente)))
    linea = fuente.count("\n", 0, pos) + 1
    inicio_linea = fuente.rfind("\n", 0, pos) + 1
    return linea, pos - inicio_linea + 1
