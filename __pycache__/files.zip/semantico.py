"""
Análisis semántico de NOPAL: tabla de símbolos con ámbitos y verificación de tipos.

Reglas verificadas:
  * variable/constante usada sin declarar
  * redeclaración en el mismo ámbito
  * asignación a una constante (incluye la variable de 'repetir')
  * incompatibilidad de tipos en operaciones, asignaciones y condiciones
  * división o módulo entre cero literal
"""
from .errores import ErrorAnalisis, linea_columna

NOMBRE_TIPO = {"numero": "número", "texto": "texto", "logico": "lógico"}


class Simbolo:
    __slots__ = ("tipo", "constante")

    def __init__(self, tipo, constante):
        self.tipo = tipo
        self.constante = constante


class AnalizadorSemantico:
    def __init__(self, fuente):
        self.fuente = fuente
        self.errores = []
        self.ambitos = [{}]

    # --- utilidades ---------------------------------------------------------
    def _error(self, pos, mensaje):
        self.errores.append(ErrorAnalisis(
            "Semántico", *linea_columna(self.fuente, pos), mensaje))

    def _buscar(self, nombre):
        for ambito in reversed(self.ambitos):
            if nombre in ambito:
                return ambito[nombre]
        return None

    @staticmethod
    def _n(tipo):
        return NOMBRE_TIPO.get(tipo, str(tipo))

    # --- recorrido ----------------------------------------------------------
    def analizar(self, sentencias):
        self._bloque(sentencias, nuevo=False)
        return self.errores

    def _bloque(self, sentencias, nuevo=True, inicial=None):
        if nuevo:
            self.ambitos.append(dict(inicial or {}))
        for s in sentencias:
            self._sentencia(s)
        if nuevo:
            self.ambitos.pop()

    def _exigir(self, nodo, esperado, contexto):
        tipo = self._tipo(nodo)
        if tipo is not None and tipo != esperado:
            self._error(nodo[1], f"{contexto} debe ser de tipo {self._n(esperado)}, "
                                 f"pero es {self._n(tipo)}")
        return tipo

    def _sentencia(self, s):
        clase = s[0]
        if clase in ("sembrar", "fijar"):
            _, pos, nombre, expr = s
            tipo = self._tipo(expr)      # primero la expresión: 'sembrar x = x;' es error
            if nombre in self.ambitos[-1]:
                self._error(pos, f"'{nombre}' ya fue declarada en este ámbito")
            else:
                self.ambitos[-1][nombre] = Simbolo(tipo, clase == "fijar")
        elif clase == "asignar":
            _, pos, nombre, expr = s
            tipo = self._tipo(expr)
            simbolo = self._buscar(nombre)
            if simbolo is None:
                self._error(pos, f"La variable '{nombre}' no ha sido declarada")
            elif simbolo.constante:
                self._error(pos, f"No se puede modificar '{nombre}': es una constante")
            elif simbolo.tipo is None:
                simbolo.tipo = tipo
            elif tipo is not None and tipo != simbolo.tipo:
                self._error(pos, f"No se puede asignar un valor {self._n(tipo)} a "
                                 f"'{nombre}' (tipo {self._n(simbolo.tipo)})")
        elif clase == "decir":
            for e in s[2]:
                self._tipo(e)
        elif clase == "si":
            _, _, cond, cuerpo, sino = s
            self._exigir(cond, "logico", "La condición del 'si'")
            self._bloque(cuerpo)
            if sino is not None:
                self._bloque(sino)
        elif clase == "mientras":
            _, _, cond, cuerpo = s
            self._exigir(cond, "logico", "La condición del 'mientras'")
            self._bloque(cuerpo)
        elif clase == "repetir":
            _, _, nombre, ini, fin, cuerpo = s
            self._exigir(ini, "numero", "El límite inicial de 'repetir'")
            self._exigir(fin, "numero", "El límite final de 'repetir'")
            self._bloque(cuerpo, inicial={nombre: Simbolo("numero", True)})

    # --- tipos de expresiones ----------------------------------------------
    def _tipo(self, n):
        clase = n[0]
        if clase == "num":
            return "numero"
        if clase == "txt":
            return "texto"
        if clase == "bool":
            return "logico"
        if clase == "id":
            simbolo = self._buscar(n[2])
            if simbolo is None:
                self._error(n[1], f"La variable '{n[2]}' no ha sido declarada")
                return None
            return simbolo.tipo
        if clase == "un":
            _, _, op, e = n
            if op == "-":
                self._exigir(e, "numero", "El operando de '-'")
                return "numero"
            self._exigir(e, "logico", "El operando de 'no'")
            return "logico"
        return self._binaria(n)

    def _binaria(self, n):
        _, pos, op, izq, der = n
        ti, td = self._tipo(izq), self._tipo(der)

        if op in ("/", "%") and der[0] == "num" and der[2] == 0:
            self._error(der[1], "División entre cero")

        if op == "+":
            if ti == "texto" or td == "texto":
                return "texto"           # concatenación
            if ti == "numero" and td == "numero":
                return "numero"
            if ti and td:
                self._error(pos, f"El operador '+' no se puede aplicar a "
                                 f"{self._n(ti)} y {self._n(td)}")
            return None
        if op in ("-", "*", "/", "%", "^", "<", ">", "<=", ">="):
            for t in (ti, td):
                if t is not None and t != "numero":
                    self._error(pos, f"El operador '{op}' requiere números, "
                                     f"pero recibió {self._n(t)}")
                    break
            return "numero" if op in ("-", "*", "/", "%", "^") else "logico"
        if op in ("==", "!="):
            if ti and td and ti != td:
                self._error(pos, f"No se pueden comparar {self._n(ti)} y {self._n(td)}")
            return "logico"
        # 'y' / 'o'
        for t in (ti, td):
            if t is not None and t != "logico":
                self._error(pos, f"El operador '{op}' requiere valores lógicos, "
                                 f"pero recibió {self._n(t)}")
                break
        return "logico"
