"""Pruebas del motor de análisis. Ejecutar desde la raíz:  python -m unittest -v"""
import unittest
from pathlib import Path

from analizador.motor import analizar

EJ = Path(__file__).resolve().parent.parent / "ejemplos"


def tipos(res):
    return [e.tipo for e in res.errores]


class PruebasNopal(unittest.TestCase):
    def test_programa_valido(self):
        res = analizar((EJ / "valido.nopal").read_text(encoding="utf-8"))
        self.assertTrue(res.valido, [e.mensaje for e in res.errores])

    def test_programa_vacio_es_valido(self):
        self.assertTrue(analizar("").valido)

    def test_error_lexico(self):
        res = analizar("sembrar x = 3 @ ;")
        self.assertIn("Léxico", tipos(res))

    def test_cadena_sin_cerrar(self):
        res = analizar('sembrar t = "hola;')
        self.assertIn("Léxico", tipos(res))

    def test_falta_punto_y_coma(self):
        res = analizar("sembrar x = 5\ndecir(x);")
        self.assertIn("Sintáctico", tipos(res))
        self.assertEqual(res.errores[0].linea, 2)

    def test_bloque_sin_cerrar(self):
        res = analizar("si (cierto) {\n decir(1);\n")
        self.assertIn("Sintáctico", tipos(res))

    def test_varios_errores_sintacticos(self):
        res = analizar("sembrar = 3;\nsembrar a = 1;\nsembrar b = 2;\nsembrar c = 3;\nsembrar y2 = ;\n")
        self.assertGreaterEqual(len([e for e in res.errores if e.tipo == "Sintáctico"]), 2)

    def test_variable_no_declarada(self):
        res = analizar("decir(z);")
        self.assertEqual(tipos(res), ["Semántico"])

    def test_constante_no_modificable(self):
        res = analizar("fijar A = 1;\nA = 2;")
        self.assertTrue(any("constante" in e.mensaje for e in res.errores))

    def test_redeclaracion(self):
        res = analizar("sembrar a = 1;\nsembrar a = 2;")
        self.assertTrue(any("ya fue declarada" in e.mensaje for e in res.errores))

    def test_tipos_incompatibles(self):
        res = analizar('sembrar a = 1;\na = "x";')
        self.assertFalse(res.valido)

    def test_condicion_no_logica(self):
        res = analizar("sembrar a = 1;\nsi (a) { decir(a); }")
        self.assertFalse(res.valido)

    def test_division_cero(self):
        res = analizar("decir(4 / 0);")
        self.assertTrue(any("cero" in e.mensaje for e in res.errores))

    def test_ambito_de_bloque(self):
        res = analizar("si (cierto) { sembrar a = 1; }\ndecir(a);")
        self.assertFalse(res.valido)

    def test_precedencia(self):
        res = analizar("sembrar a = 2 + 3 * 4 ^ 2;\nsi (a == 50 y no falso) { decir(a); }")
        self.assertTrue(res.valido)

    def test_ejemplos_con_error(self):
        for nombre in ("error_lexico_sintactico.nopal", "error_semantico.nopal"):
            res = analizar((EJ / nombre).read_text(encoding="utf-8"))
            self.assertFalse(res.valido, nombre)


if __name__ == "__main__":
    unittest.main()
