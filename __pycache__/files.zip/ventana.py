"""Ventana principal del IDE de NOPAL (PyQt6)."""
import html
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtGui import (QAction, QFontDatabase, QKeySequence, QShortcut,
                         QTextCursor, QTextDocument)
from PyQt6.QtWidgets import (QAbstractItemView, QCheckBox, QFileDialog, QHBoxLayout,
                             QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox,
                             QPushButton, QSplitter, QTableWidget, QTableWidgetItem,
                             QTabWidget, QTextEdit, QVBoxLayout, QWidget)

from analizador.motor import analizar
from .editor_codigo import EditorCodigo, ResaltadorNopal

FILTRO_ARCHIVOS = "Código NOPAL (*.nopal);;Todos los archivos (*)"

PLANTILLA = '''~ Bienvenido a NOPAL: escribe tu código y presiona F5
fijar saludo = "Hola desde Pachuca";
sembrar total = 0;

repetir i desde 1 hasta 5 {
    total = total + i;
}

si (total > 10) {
    decir(saludo, " - total: ", total);
} sino {
    decir("Total pequeño");
}
'''


class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ruta = None
        self.resize(1150, 780)

        self._crear_editor()
        self._crear_barra_busqueda()
        self._crear_paneles_resultado()
        self._armar_layout()
        self._crear_acciones()
        self._crear_menus_y_barra()

        self.etiqueta_cursor = QLabel("Ln 1, Col 1")
        self.statusBar().addPermanentWidget(self.etiqueta_cursor)
        self.editor.cursorPositionChanged.connect(self._actualizar_cursor)

        self.editor.setPlainText(PLANTILLA)
        self.editor.document().setModified(False)
        self.editor.document().modificationChanged.connect(self.setWindowModified)
        self._actualizar_titulo()
        self.statusBar().showMessage("Listo. Presiona F5 para analizar.")

    # ======================================================================
    # Construcción de la interfaz
    # ======================================================================
    def _crear_editor(self):
        self.editor = EditorCodigo()
        fuente = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        fuente.setPointSize(12)
        self.editor.establecer_fuente(fuente)
        self.resaltador = ResaltadorNopal(self.editor.document())

    def _crear_barra_busqueda(self):
        self.barra_busqueda = QWidget()
        lay = QHBoxLayout(self.barra_busqueda)
        lay.setContentsMargins(4, 2, 4, 2)

        self.txt_buscar = QLineEdit(placeholderText="Buscar…")
        self.txt_reemplazar = QLineEdit(placeholderText="Reemplazar por…")
        self.chk_mayusculas = QCheckBox("Distinguir mayúsculas")
        btn_ant = QPushButton("▲ Anterior")
        btn_sig = QPushButton("▼ Siguiente")
        btn_rep = QPushButton("Reemplazar")
        btn_todo = QPushButton("Reemplazar todo")
        btn_cerrar = QPushButton("✕")
        btn_cerrar.setFixedWidth(28)

        self.txt_buscar.returnPressed.connect(lambda: self.buscar(False))
        btn_sig.clicked.connect(lambda: self.buscar(False))
        btn_ant.clicked.connect(lambda: self.buscar(True))
        btn_rep.clicked.connect(self.reemplazar)
        btn_todo.clicked.connect(self.reemplazar_todo)
        btn_cerrar.clicked.connect(self.ocultar_busqueda)

        for w in (self.txt_buscar, btn_ant, btn_sig, self.txt_reemplazar,
                  btn_rep, btn_todo, self.chk_mayusculas, btn_cerrar):
            lay.addWidget(w)
        QShortcut(QKeySequence("Esc"), self.barra_busqueda, self.ocultar_busqueda,
                  context=Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self.barra_busqueda.hide()

    def _crear_paneles_resultado(self):
        self.vista_resultado = QTextEdit()
        self.vista_resultado.setReadOnly(True)

        self.tabla_errores = self._nueva_tabla(["Tipo", "Línea", "Columna", "Descripción"])
        self.tabla_errores.cellDoubleClicked.connect(self._ir_a_error)
        self.tabla_tokens = self._nueva_tabla(["Token", "Lexema", "Línea", "Columna"])

        self.pestanas = QTabWidget()
        self.pestanas.addTab(self.vista_resultado, "Resultado")
        self.pestanas.addTab(self.tabla_errores, "Errores")
        self.pestanas.addTab(self.tabla_tokens, "Tokens")

    @staticmethod
    def _nueva_tabla(columnas):
        tabla = QTableWidget(0, len(columnas))
        tabla.setHorizontalHeaderLabels(columnas)
        tabla.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tabla.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tabla.verticalHeader().setVisible(False)
        tabla.horizontalHeader().setSectionResizeMode(
            len(columnas) - 1 if columnas[-1] == "Descripción" else 1,
            QHeaderView.ResizeMode.Stretch)
        return tabla

    def _armar_layout(self):
        arriba = QWidget()
        lay = QVBoxLayout(arriba)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.editor)
        lay.addWidget(self.barra_busqueda)

        divisor = QSplitter(Qt.Orientation.Vertical)
        divisor.addWidget(arriba)
        divisor.addWidget(self.pestanas)
        divisor.setStretchFactor(0, 3)
        divisor.setStretchFactor(1, 2)
        self.setCentralWidget(divisor)

    def _crear_acciones(self):
        SK = QKeySequence.StandardKey

        def accion(texto, atajo, slot):
            a = QAction(texto, self)
            if atajo is not None:
                a.setShortcut(QKeySequence(atajo))
            a.triggered.connect(slot)
            return a

        self.a_nuevo = accion("&Nuevo", SK.New, self.nuevo)
        self.a_abrir = accion("&Abrir…", SK.Open, self.abrir)
        self.a_guardar = accion("&Guardar", SK.Save, self.guardar)
        self.a_guardar_como = accion("Guardar &como…", SK.SaveAs, self.guardar_como)
        self.a_salir = accion("&Salir", "Ctrl+Q", self.close)

        self.a_deshacer = accion("&Deshacer", SK.Undo, self.editor.undo)
        self.a_rehacer = accion("&Rehacer", SK.Redo, self.editor.redo)
        self.a_cortar = accion("Cor&tar", SK.Cut, self.editor.cut)
        self.a_copiar = accion("&Copiar", SK.Copy, self.editor.copy)
        self.a_pegar = accion("&Pegar", SK.Paste, self.editor.paste)
        self.a_todo = accion("Seleccionar &todo", SK.SelectAll, self.editor.selectAll)
        self.a_buscar = accion("&Buscar…", SK.Find, lambda: self.mostrar_busqueda(False))
        self.a_reemplazar = accion("&Reemplazar…", "Ctrl+H",
                                   lambda: self.mostrar_busqueda(True))
        self.a_sig = accion("Buscar siguiente", "F3", lambda: self.buscar(False))
        self.a_ant = accion("Buscar anterior", "Shift+F3", lambda: self.buscar(True))

        self.a_analizar = accion("▶ &Analizar", "F5", self.analizar_codigo)
        self.a_acerca = accion("&Acerca de", None, self.acerca_de)

        # habilitar/deshabilitar según el estado del editor
        for a in (self.a_cortar, self.a_copiar):
            a.setEnabled(False)
        self.a_deshacer.setEnabled(False)
        self.a_rehacer.setEnabled(False)
        self.editor.copyAvailable.connect(self.a_cortar.setEnabled)
        self.editor.copyAvailable.connect(self.a_copiar.setEnabled)
        self.editor.undoAvailable.connect(self.a_deshacer.setEnabled)
        self.editor.redoAvailable.connect(self.a_rehacer.setEnabled)

    def _crear_menus_y_barra(self):
        m = self.menuBar()
        archivo = m.addMenu("&Archivo")
        archivo.addActions([self.a_nuevo, self.a_abrir, self.a_guardar, self.a_guardar_como])
        archivo.addSeparator()
        archivo.addAction(self.a_salir)

        editar = m.addMenu("&Editar")
        editar.addActions([self.a_deshacer, self.a_rehacer])
        editar.addSeparator()
        editar.addActions([self.a_cortar, self.a_copiar, self.a_pegar, self.a_todo])
        editar.addSeparator()
        editar.addActions([self.a_buscar, self.a_reemplazar, self.a_sig, self.a_ant])

        m.addMenu("&Analizar").addAction(self.a_analizar)
        m.addMenu("A&yuda").addAction(self.a_acerca)

        barra = self.addToolBar("Principal")
        barra.setMovable(False)
        barra.addActions([self.a_nuevo, self.a_abrir, self.a_guardar])
        barra.addSeparator()
        barra.addActions([self.a_cortar, self.a_copiar, self.a_pegar])
        barra.addSeparator()
        barra.addActions([self.a_buscar, self.a_analizar])

    # ======================================================================
    # Archivo
    # ======================================================================
    def _actualizar_titulo(self):
        nombre = Path(self.ruta).name if self.ruta else "sin_titulo.nopal"
        self.setWindowTitle(f"{nombre}[*] — NOPAL IDE")

    def _confirmar_descarte(self):
        if not self.editor.document().isModified():
            return True
        r = QMessageBox.question(
            self, "Cambios sin guardar", "El documento tiene cambios sin guardar.\n¿Deseas guardarlos?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
            | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Save:
            return self.guardar()
        return r == QMessageBox.StandardButton.Discard

    def nuevo(self):
        if self._confirmar_descarte():
            self.editor.clear()
            self.ruta = None
            self.editor.document().setModified(False)
            self._limpiar_resultados()
            self._actualizar_titulo()

    def abrir(self):
        if not self._confirmar_descarte():
            return
        ruta, _ = QFileDialog.getOpenFileName(self, "Abrir archivo", "", FILTRO_ARCHIVOS)
        if not ruta:
            return
        try:
            self.editor.setPlainText(Path(ruta).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError) as e:
            QMessageBox.critical(self, "Error", f"No se pudo abrir el archivo:\n{e}")
            return
        self.ruta = ruta
        self.editor.document().setModified(False)
        self._limpiar_resultados()
        self._actualizar_titulo()
        self.statusBar().showMessage(f"Abierto: {ruta}", 4000)

    def guardar(self):
        return self._escribir(self.ruta) if self.ruta else self.guardar_como()

    def guardar_como(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar como", "", FILTRO_ARCHIVOS)
        if not ruta:
            return False
        if not Path(ruta).suffix:
            ruta += ".nopal"
        return self._escribir(ruta)

    def _escribir(self, ruta):
        try:
            Path(ruta).write_text(self.editor.toPlainText(), encoding="utf-8")
        except OSError as e:
            QMessageBox.critical(self, "Error", f"No se pudo guardar:\n{e}")
            return False
        self.ruta = ruta
        self.editor.document().setModified(False)
        self._actualizar_titulo()
        self.statusBar().showMessage(f"Guardado: {ruta}", 4000)
        return True

    def closeEvent(self, evento):
        if self._confirmar_descarte():
            evento.accept()
        else:
            evento.ignore()

    # ======================================================================
    # Buscar / reemplazar
    # ======================================================================
    def mostrar_busqueda(self, con_reemplazo):
        self.barra_busqueda.show()
        seleccion = self.editor.textCursor().selectedText()
        if seleccion and "\u2029" not in seleccion:
            self.txt_buscar.setText(seleccion)
        (self.txt_reemplazar if con_reemplazo else self.txt_buscar).setFocus()
        self.txt_buscar.selectAll()

    def ocultar_busqueda(self):
        self.barra_busqueda.hide()
        self.editor.setFocus()

    def _opciones(self, atras=False):
        op = QTextDocument.FindFlag(0)
        if self.chk_mayusculas.isChecked():
            op |= QTextDocument.FindFlag.FindCaseSensitively
        if atras:
            op |= QTextDocument.FindFlag.FindBackward
        return op

    def buscar(self, atras=False):
        texto = self.txt_buscar.text()
        if not texto:
            return False
        if self.editor.find(texto, self._opciones(atras)):
            return True
        # volver a empezar desde el otro extremo del documento
        cur = self.editor.textCursor()
        cur.movePosition(QTextCursor.MoveOperation.End if atras
                         else QTextCursor.MoveOperation.Start)
        self.editor.setTextCursor(cur)
        if self.editor.find(texto, self._opciones(atras)):
            self.statusBar().showMessage("Se reinició la búsqueda desde el otro extremo", 2500)
            return True
        self.statusBar().showMessage(f"No se encontró «{texto}»", 3000)
        return False

    def reemplazar(self):
        texto = self.txt_buscar.text()
        sel = self.editor.textCursor().selectedText()
        coincide = (sel == texto) if self.chk_mayusculas.isChecked() \
            else (sel.lower() == texto.lower())
        if texto and coincide:
            self.editor.textCursor().insertText(self.txt_reemplazar.text())
        self.buscar(False)

    def reemplazar_todo(self):
        texto = self.txt_buscar.text()
        if not texto:
            return
        doc = self.editor.document()
        cursor = QTextCursor(doc)
        cursor.beginEditBlock()
        total = 0
        while True:
            encontrado = doc.find(texto, cursor, self._opciones())
            if encontrado.isNull():
                break
            encontrado.insertText(self.txt_reemplazar.text())
            cursor = encontrado
            total += 1
        cursor.endEditBlock()
        self.statusBar().showMessage(f"{total} reemplazo(s) realizado(s)", 4000)

    # ======================================================================
    # Análisis
    # ======================================================================
    def _limpiar_resultados(self):
        self.vista_resultado.clear()
        self.tabla_errores.setRowCount(0)
        self.tabla_tokens.setRowCount(0)
        self.editor.marcar_errores([])

    def analizar_codigo(self):
        try:
            res = analizar(self.editor.toPlainText())
        except Exception as e:  # defensa: el IDE nunca debe cerrarse por un fallo interno
            QMessageBox.critical(self, "Error interno del analizador", repr(e))
            return

        # tabla de errores
        self.tabla_errores.setRowCount(len(res.errores))
        for fila, err in enumerate(res.errores):
            for col, valor in enumerate((err.tipo, err.linea, err.columna, err.mensaje)):
                self.tabla_errores.setItem(fila, col, QTableWidgetItem(str(valor)))
        self.tabla_errores.resizeColumnsToContents()
        self.tabla_errores.horizontalHeader().setStretchLastSection(True)

        # tabla de tokens
        self.tabla_tokens.setRowCount(len(res.tokens))
        for fila, tok in enumerate(res.tokens):
            for col, valor in enumerate(tok):
                self.tabla_tokens.setItem(fila, col, QTableWidgetItem(str(valor)))

        self.editor.marcar_errores({e.linea for e in res.errores})

        # panel de resultado
        if res.valido:
            cuerpo = (
                "<h2 style='color:#2e9e4f'>✔ Código válido</h2>"
                "<p>No se encontraron errores léxicos, sintácticos ni semánticos.</p>"
                f"<p><b>Tokens reconocidos:</b> {len(res.tokens)}<br>"
                f"<b>Sentencias analizadas:</b> {res.num_sentencias}</p>")
            self.pestanas.setCurrentIndex(0)
            self.statusBar().showMessage("✔ Código válido", 5000)
        else:
            n = len(res.errores)
            filas = "".join(
                f"<li><b>[{html.escape(e.tipo)}]</b> línea {e.linea}, columna {e.columna}: "
                f"{html.escape(e.mensaje)}</li>" for e in res.errores)
            cuerpo = (f"<h2 style='color:#d64545'>✘ Código inválido</h2>"
                      f"<p>Se encontraron <b>{n}</b> error(es):</p><ul>{filas}</ul>")
            if res.semantico_omitido:
                cuerpo += ("<p><i>El análisis semántico se realiza cuando el código no tiene "
                           "errores léxicos ni sintácticos.</i></p>")
            self.pestanas.setCurrentIndex(0)
            self.statusBar().showMessage(f"✘ {n} error(es) encontrado(s)", 5000)
        self.vista_resultado.setHtml(cuerpo)

    def _ir_a_error(self, fila, _col):
        linea = int(self.tabla_errores.item(fila, 1).text())
        columna = int(self.tabla_errores.item(fila, 2).text())
        bloque = self.editor.document().findBlockByNumber(linea - 1)
        if not bloque.isValid():
            return
        cur = QTextCursor(bloque)
        cur.setPosition(bloque.position() + min(columna - 1, max(0, bloque.length() - 1)))
        self.editor.setTextCursor(cur)
        self.editor.setFocus()

    def _actualizar_cursor(self):
        cur = self.editor.textCursor()
        self.etiqueta_cursor.setText(f"Ln {cur.blockNumber() + 1}, Col {cur.columnNumber() + 1}")

    def acerca_de(self):
        QMessageBox.about(
            self, "Acerca de NOPAL IDE",
            "<b>NOPAL IDE</b><br>Editor y analizador del lenguaje NOPAL.<br>"
            "Construido con Python, PyQt6 y PLY.")
