# NOPAL — lenguaje de programación + IDE

NOPAL es un lenguaje con palabras clave en español, pensado para enseñar los
conceptos básicos de programación (variables, constantes, condicionales y ciclos).
Este proyecto incluye:

* **Analizador** (carpeta `analizador/`) hecho con **PLY**: léxico, sintáctico y semántico.
* **IDE** (carpeta `gui/`) hecho con **PyQt6**: editor con números de línea, resaltado de
  sintaxis, copiar / cortar / pegar / buscar / reemplazar, y paneles de resultado.

## Manual de configuración

```bash
# 1. Clonar
git clone <URL-DEL-REPOSITORIO>
cd nopal

# 2. Entorno virtual (recomendado)
python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # Linux / macOS

# 3. Dependencias
pip install -r requirements.txt

# 4. Ejecutar
python main.py

# 5. (Opcional) pruebas automáticas
python -m unittest -v
```

En PyCharm: *File → Open* la carpeta del proyecto, configurar el intérprete (venv),
instalar `requirements.txt` y ejecutar `main.py`.

## Uso del IDE

| Acción | Atajo |
|---|---|
| Nuevo / Abrir / Guardar | Ctrl+N / Ctrl+O / Ctrl+S |
| Cortar / Copiar / Pegar | Ctrl+X / Ctrl+C / Ctrl+V |
| Buscar / Reemplazar | Ctrl+F / Ctrl+H (F3 siguiente, Shift+F3 anterior) |
| **Analizar** | **F5** |

Tras analizar, la pestaña **Resultado** indica si el código es válido; **Errores** lista
tipo, línea, columna y descripción (doble clic salta al error); **Tokens** muestra la
tabla léxica. Las líneas con error se marcan en rojo.

## Reglas del lenguaje

* Cada sentencia simple termina en `;`. Los bloques usan `{ }`.
* Comentarios: `~ de una línea` y `~* de varias líneas *~`.
* Tipos (inferidos): **número** (`3`, `2.5`), **texto** (`"hola"`), **lógico** (`cierto`, `falso`).
* `sembrar x = 5;` declara una variable; `fijar PI = 3.14;` una constante.
* `decir(a, b, ...);` imprime valores.
* Condicional: `si (cond) { } sino si (cond) { } sino { }`.
* Ciclos: `mientras (cond) { }` y `repetir i desde 1 hasta 10 { }`
  (`i` es de solo lectura y solo existe dentro del ciclo).
* Operadores: `+ - * / % ^`, `== != < > <= >=`, `y`, `o`, `no`. `+` también concatena texto.
* Ámbitos: cada bloque tiene su propio ámbito.

### Errores que detecta

* **Léxicos:** caracteres no reconocidos, cadenas y comentarios de bloque sin cerrar.
* **Sintácticos:** falta de `;`, llaves/paréntesis, sentencias incompletas (con recuperación
  de errores, así que informa varios en una sola pasada).
* **Semánticos:** variable no declarada, redeclaración, modificar una constante,
  tipos incompatibles, condición no lógica, división entre cero literal.

## Gramática

Definida en `analizador/lexico.py` (tokens y expresiones regulares) y
`analizador/sintactico.py` (producciones).

```
programa        → sentencias
sentencias      → sentencias sentencia | ε
sentencia       → declaracion | constante | asignacion | impresion
                | condicional | ciclo_mientras | ciclo_repetir
                | error ';'                       (recuperación de errores)
declaracion     → SEMBRAR ID '=' expresion ';'
constante       → FIJAR ID '=' expresion ';'
asignacion      → ID '=' expresion ';'
impresion       → DECIR '(' lista_expresiones ')' ';'
lista_expresiones → lista_expresiones ',' expresion | expresion
condicional     → SI '(' expresion ')' bloque
                | SI '(' expresion ')' bloque SINO bloque
                | SI '(' expresion ')' bloque SINO condicional
ciclo_mientras  → MIENTRAS '(' expresion ')' bloque
ciclo_repetir   → REPETIR ID DESDE expresion HASTA expresion bloque
bloque          → '{' sentencias '}'
expresion       → expresion (+ - * / % ^ == != < > <= >= y o) expresion
                | '-' expresion | NO expresion | '(' expresion ')'
                | NUMERO | TEXTO | CIERTO | FALSO | ID
```

Precedencia (de menor a mayor): `o` < `y` < `no` < comparaciones < `+ -` < `* / %` < `-` unario < `^`.

### Tokens y expresiones regulares

| Token | Expresión regular |
|---|---|
| ID | `[A-Za-z_áéíóúüñÁÉÍÓÚÜÑ][A-Za-z0-9_áéíóúüñÁÉÍÓÚÜÑ]*` |
| NUMERO | `\d+(\.\d+)?` |
| TEXTO | `"([^"\\\n]\|\\.)*"` |
| Comentario línea | `~(?!\*)[^\n]*` |
| Comentario bloque | `~\*[\s\S]*?\*~` |
| Operadores / delimitadores | `+ - * / % ^ == != <= >= < > = ( ) { } ; ,` |
| Palabras reservadas | sembrar fijar decir si sino mientras repetir desde hasta cierto falso y o no |

## Estructura

```
main.py                    arranque del IDE
analizador/  lexico.py  sintactico.py  semantico.py  motor.py  errores.py
gui/         ventana.py  editor_codigo.py
ejemplos/    valido.nopal  error_lexico_sintactico.nopal  error_semantico.nopal
tests/       test_analizador.py
```
