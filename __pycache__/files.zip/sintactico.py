"""
Analizador sintáctico del lenguaje NOPAL (PLY - yacc).

La gramática completa está documentada en README.md.
"""
import re
import sys
import ply.yacc as yacc

from .lexico import tokens, construir_lexer          # noqa: F401  (yacc usa 'tokens')
from .errores import ErrorAnalisis, linea_columna

start = "programa"

precedence = (
    ("left", "O"),
    ("left", "Y"),
    ("right", "NO"),
    ("nonassoc", "IGUALIGUAL", "DIFERENTE", "MENORQUE", "MAYORQUE",
     "MENORIGUAL", "MAYORIGUAL"),
    ("left", "MAS", "MENOS"),
    ("left", "POR", "DIV", "MOD"),
    ("right", "UMENOS"),
    ("right", "POT"),
)

_errores = []
_fuente = ""
_parser = None


# ----------------------------------------------------------------------------
# Producciones
# ----------------------------------------------------------------------------
def p_programa(p):
    """programa : sentencias"""
    p[0] = p[1]


def p_sentencias_lista(p):
    """sentencias : sentencias sentencia"""
    if p[2] is not None:
        p[1].append(p[2])
    p[0] = p[1]


def p_sentencias_vacio(p):
    """sentencias : empty"""
    p[0] = []


def p_empty(p):
    """empty :"""
    pass


def p_sentencia(p):
    """sentencia : declaracion
                 | constante
                 | asignacion
                 | impresion
                 | condicional
                 | ciclo_mientras
                 | ciclo_repetir"""
    p[0] = p[1]


def p_sentencia_error(p):
    """sentencia : error PUNTOCOMA"""
    p[0] = None   # recuperación de errores: descarta hasta el siguiente ';'


def p_declaracion(p):
    """declaracion : SEMBRAR ID IGUAL expresion PUNTOCOMA"""
    p[0] = ("sembrar", p.lexpos(2), p[2], p[4])


def p_constante(p):
    """constante : FIJAR ID IGUAL expresion PUNTOCOMA"""
    p[0] = ("fijar", p.lexpos(2), p[2], p[4])


def p_asignacion(p):
    """asignacion : ID IGUAL expresion PUNTOCOMA"""
    p[0] = ("asignar", p.lexpos(1), p[1], p[3])


def p_impresion(p):
    """impresion : DECIR PARIZQ lista_expresiones PARDER PUNTOCOMA"""
    p[0] = ("decir", p.lexpos(1), p[3])


def p_lista_expresiones_varias(p):
    """lista_expresiones : lista_expresiones COMA expresion"""
    p[0] = p[1] + [p[3]]


def p_lista_expresiones_una(p):
    """lista_expresiones : expresion"""
    p[0] = [p[1]]


def p_condicional_simple(p):
    """condicional : SI PARIZQ expresion PARDER bloque"""
    p[0] = ("si", p.lexpos(1), p[3], p[5], None)


def p_condicional_sino(p):
    """condicional : SI PARIZQ expresion PARDER bloque SINO bloque"""
    p[0] = ("si", p.lexpos(1), p[3], p[5], p[7])


def p_condicional_sino_si(p):
    """condicional : SI PARIZQ expresion PARDER bloque SINO condicional"""
    p[0] = ("si", p.lexpos(1), p[3], p[5], [p[7]])


def p_ciclo_mientras(p):
    """ciclo_mientras : MIENTRAS PARIZQ expresion PARDER bloque"""
    p[0] = ("mientras", p.lexpos(1), p[3], p[5])


def p_ciclo_repetir(p):
    """ciclo_repetir : REPETIR ID DESDE expresion HASTA expresion bloque"""
    p[0] = ("repetir", p.lexpos(2), p[2], p[4], p[6], p[7])


def p_bloque(p):
    """bloque : LLAVEIZQ sentencias LLAVEDER"""
    p[0] = p[2]


# --- Expresiones ------------------------------------------------------------
def p_expresion_binaria(p):
    """expresion : expresion MAS expresion
                 | expresion MENOS expresion
                 | expresion POR expresion
                 | expresion DIV expresion
                 | expresion MOD expresion
                 | expresion POT expresion
                 | expresion IGUALIGUAL expresion
                 | expresion DIFERENTE expresion
                 | expresion MENORQUE expresion
                 | expresion MAYORQUE expresion
                 | expresion MENORIGUAL expresion
                 | expresion MAYORIGUAL expresion
                 | expresion Y expresion
                 | expresion O expresion"""
    p[0] = ("bin", p.lexpos(2), p[2], p[1], p[3])


def p_expresion_menos_unario(p):
    """expresion : MENOS expresion %prec UMENOS"""
    p[0] = ("un", p.lexpos(1), "-", p[2])


def p_expresion_no(p):
    """expresion : NO expresion"""
    p[0] = ("un", p.lexpos(1), "no", p[2])


def p_expresion_agrupada(p):
    """expresion : PARIZQ expresion PARDER"""
    p[0] = p[2]


def p_expresion_numero(p):
    """expresion : NUMERO"""
    valor = float(p[1]) if "." in p[1] else int(p[1])
    p[0] = ("num", p.lexpos(1), valor)


def p_expresion_texto(p):
    """expresion : TEXTO"""
    crudo = p[1][1:-1]
    mapa = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}
    valor = re.sub(r"\\(.)", lambda m: mapa.get(m.group(1), m.group(0)), crudo)
    p[0] = ("txt", p.lexpos(1), valor)


def p_expresion_logico(p):
    """expresion : CIERTO
                 | FALSO"""
    p[0] = ("bool", p.lexpos(1), p[1] == "cierto")


def p_expresion_id(p):
    """expresion : ID"""
    p[0] = ("id", p.lexpos(1), p[1])


# ----------------------------------------------------------------------------
# Manejo de errores sintácticos
# ----------------------------------------------------------------------------
_NOMBRES = {
    "PUNTOCOMA": "';'", "PARIZQ": "'('", "PARDER": "')'", "LLAVEIZQ": "'{'",
    "LLAVEDER": "'}'", "IGUAL": "'='", "COMA": "','", "ID": "un identificador",
    "NUMERO": "un número", "TEXTO": "un texto", "DESDE": "'desde'",
    "HASTA": "'hasta'", "SINO": "'sino'",
}


def _esperados():
    """Tokens que la tabla LALR aceptaba en el estado donde ocurrió el error."""
    try:
        estado = _parser.statestack[-1]
        return [k for k in _parser.action[estado] if k not in ("$end", "error")]
    except Exception:
        return []


def p_error(t):
    esperados = _esperados()
    if t is None:
        linea, col = linea_columna(_fuente, len(_fuente.rstrip()))
        if "LLAVEDER" in esperados:
            msg = "Fin de archivo inesperado: falta cerrar un bloque con '}'"
        elif "PUNTOCOMA" in esperados:
            msg = "Fin de archivo inesperado: falta ';' al final de la sentencia"
        else:
            msg = "Fin de archivo inesperado: la sentencia está incompleta"
    else:
        linea, col = linea_columna(_fuente, t.lexpos)
        lexema = str(t.value)
        if "PUNTOCOMA" in esperados:
            msg = f"Se esperaba ';' antes de '{lexema}'"
        elif 0 < len(esperados) <= 4:
            lista = " o ".join(_NOMBRES.get(k, k.lower()) for k in esperados)
            msg = f"Token inesperado '{lexema}'; se esperaba {lista}"
        else:
            msg = f"Token inesperado '{lexema}'"
    _errores.append(ErrorAnalisis("Sintáctico", linea, col, msg))


# ----------------------------------------------------------------------------
# API
# ----------------------------------------------------------------------------
def _obtener_parser():
    global _parser
    if _parser is None:
        _parser = yacc.yacc(module=sys.modules[__name__], debug=False,
                            write_tables=False)
    return _parser


def analizar_sintaxis(fuente: str):
    """Devuelve (ast, errores_sintácticos). ast es una lista de sentencias."""
    global _fuente
    _errores.clear()
    _fuente = fuente
    parser = _obtener_parser()
    ast = parser.parse(fuente, lexer=construir_lexer(), tracking=True)
    return ast, list(_errores)
