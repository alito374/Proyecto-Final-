"""Orquesta las tres fases (léxica, sintáctica y semántica) y entrega un Resultado."""
from dataclasses import dataclass, field

from .lexico import tokenizar
from .sintactico import analizar_sintaxis
from .semantico import AnalizadorSemantico


@dataclass
class Resultado:
    valido: bool
    errores: list = field(default_factory=list)
    tokens: list = field(default_factory=list)
    ast: list = None
    num_sentencias: int = 0
    semantico_omitido: bool = False


def _contar(sentencias):
    total = 0
    for s in sentencias or []:
        total += 1
        if s[0] == "si":
            total += _contar(s[3]) + _contar(s[4])
        elif s[0] == "mientras":
            total += _contar(s[3])
        elif s[0] == "repetir":
            total += _contar(s[5])
    return total


def analizar(codigo: str) -> Resultado:
    tokens, err_lex = tokenizar(codigo)
    ast, err_sint = analizar_sintaxis(codigo)

    errores = list(err_lex) + list(err_sint)
    omitido = False
    if not errores and ast is not None:
        errores += AnalizadorSemantico(codigo).analizar(ast)
    else:
        omitido = True

    errores.sort(key=lambda e: (e.linea, e.columna))
    return Resultado(
        valido=not errores,
        errores=errores,
        tokens=tokens,
        ast=ast,
        num_sentencias=_contar(ast),
        semantico_omitido=omitido and bool(errores),
    )
